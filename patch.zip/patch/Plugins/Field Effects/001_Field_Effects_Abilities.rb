#============================================================================
#
#
#
#============================================================================

#		FIELD EFFECTS IN ORDER OF NUMBER
#
#	1|	Example Field
#	2|	Volcanic Field
#	3|	Cave Field
#	4|	Forest Field
#	5|      Beach Field
#       6|  Sky Field


#==================================
# 		ABILITY CHANGES
#==================================

# OVERGROW
Battle::AbilityEffects::DamageCalcFromUser.add(:OVERGROW,
  proc { |ability, user, target, move, mults, baseDmg, type|
										# Forest Field				
    if (user.hp <= user.totalhp / 3 || $game_temp.fieldEffectsBg == 4) && type == :GRASS
      mults[:attack_multiplier] *= 1.5
    end
  }
)

# SWARM
Battle::AbilityEffects::DamageCalcFromUser.add(:SWARM,
  proc { |ability, user, target, move, mults, baseDmg, type|
										# Forest Field
    if (user.hp <= user.totalhp / 3 || $game_temp.fieldEffectsBg == 4) && type == :BUG
      mults[:attack_multiplier] *= 1.5
    end
  }
)

# BLAZE
Battle::AbilityEffects::DamageCalcFromUser.add(:BLAZE,
  proc { |ability, user, target, move, mults, baseDmg, type|
										# Volcanic Field			
    if (user.hp <= user.totalhp / 3 || $game_temp.fieldEffectsBg == 2) && type == :FIRE
      mults[:attack_multiplier] *= 1.5
    end
  }
)

# EFFECT SPORE
Battle::AbilityEffects::OnBeingHit.add(:EFFECTSPORE,
  proc { |ability, user, target, move, battle|
    # NOTE: This ability has a 30% chance of triggering, not a 30% chance of
    #       inflicting a status condition. It can try (and fail) to inflict a
    #       status condition that the user is immune to.
    next if !move.pbContactMove?(user)
	# NOTE_2: Its stupidly easy to boost the chance of the ability triggering based on Field
	# as seen below
	if $game_temp.fieldEffectsBg == 4 # Forest Field
	   next if battle.pbRandom(100) >= 60
	else
	   next if battle.pbRandom(100) >= 30
	end 
    r = battle.pbRandom(3)
    next if r == 0 && user.asleep?
    next if r == 1 && user.poisoned?
    next if r == 2 && user.paralyzed?
    battle.pbShowAbilitySplash(target)
    if user.affectedByPowder?(Battle::Scene::USE_ABILITY_SPLASH) &&
       user.affectedByContactEffect?(Battle::Scene::USE_ABILITY_SPLASH)
      case r
      when 0
        if user.pbCanSleep?(target, Battle::Scene::USE_ABILITY_SPLASH)
          msg = nil
          if !Battle::Scene::USE_ABILITY_SPLASH
            msg = _INTL("{1}'s {2} made {3} fall asleep!", target.pbThis,
               target.abilityName, user.pbThis(true))
          end
          user.pbSleep(msg)
        end
      when 1
        if user.pbCanPoison?(target, Battle::Scene::USE_ABILITY_SPLASH)
          msg = nil
          if !Battle::Scene::USE_ABILITY_SPLASH
            msg = _INTL("{1}'s {2} poisoned {3}!", target.pbThis,
               target.abilityName, user.pbThis(true))
          end
          user.pbPoison(target, msg)
        end
      when 2
        if user.pbCanParalyze?(target, Battle::Scene::USE_ABILITY_SPLASH)
          msg = nil
          if !Battle::Scene::USE_ABILITY_SPLASH
            msg = _INTL("{1}'s {2} paralyzed {3}! It may be unable to move!",
               target.pbThis, target.abilityName, user.pbThis(true))
          end
          user.pbParalyze(target, msg)
        end
      end
    end
    battle.pbHideAbilitySplash(target)
  }
)

# NOTE: If you want to lower the accuracy of Pokémon having X ability, 
#		do it as seen below.

# LONG REACH
Battle::AbilityEffects::AccuracyCalcFromUser.add(:LONGREACH,
  proc { |ability, mods, user, target, move, type|
    mods[:accuracy_multiplier] *= 0.9 if $game_temp.fieldEffectsBg == 4 # Forest Field
  }
)

# NOTE: As seen below, Solid Rock checks if the Move is Supereffective to then decrease its power.
#		Here, we are telling to verify if its Super-Effective OR Pokémon with Solid Rock is on Example Field
#		if yes, then all damage recieved is decreased.

# SOLID ROCK
Battle::AbilityEffects::DamageCalcFromTarget.add(:SOLIDROCK,
  proc { |ability, user, target, move, mults, baseDmg, type|
    if Effectiveness.super_effective?(target.damageState.typeMod) || 
		$game_temp.fieldEffectsBg == 1 # Example Field
      mults[:final_damage_multiplier] *= 0.75
    end
  }
)

# NOTE: As seen below, KEENEYE OnSwitchIn is skipped if the field ISNT the Example Field
#		its easier to use a 'next if x' than to do a 'if end' or 'if elsif end' 
#		Same thing is made for WATERABSORB and healing at the end of turn, skip if not on Example Field
#		skip if the bearer of the ability is airborne, and skip if the bearer cant be healed
#		Same deal for Water Compaction

# KEENEYE
Battle::AbilityEffects::OnSwitchIn.add(:KEENEYE,
  proc { |ability, battler, battle, switch_in|
    next if $game_temp.fieldEffectsBg != 1 # Example Field
    battler.pbRaiseStatStageByAbility(:EVASION, 1, battler)
  }
)

# WATER ABSORB 
Battle::AbilityEffects::EndOfRoundHealing.add(:WATERABSORB,
  proc { |ability, battler, battle|
    next if $game_temp.fieldEffectsBg != 1 # Example Field
	next if battler.airborne?
    next if !battler.canHeal?
    battler.pbRecoverHP(battler.totalhp / 16)
    battle.pbDisplay(_INTL("{1} restored a little HP!",battler.pbThis))
  }
)

# WATER COMPACTION
Battle::AbilityEffects::EndOfRoundEffect.add(:WATERCOMPACTION,
  proc { |ability, battler, battle|
    next if $game_temp.fieldEffectsBg != 1 # Example Field
	battler.pbRaiseStatStageByAbility(:DEFENSE, 2, battler) if battler.pbCanRaiseStatStage?(:DEFENSE, battler)
  }
)

# GRASS PELT
Battle::AbilityEffects::DamageCalcFromTarget.add(:GRASSPELT,
  proc { |ability, user, target, move, mults, baseDmg, type|
    if $game_temp.terrainEffectsBg == 1 || # Grassy Terrain
	   $game_temp.fieldEffectsBg == 4 # Forest Field
      mults[:defense_multiplier] *= 1.5
    end
  }
)

# LEAF GUARD
Battle::AbilityEffects::StatusImmunity.add(:LEAFGUARD,
  proc { |ability, battler, status|
																				# Forest Field
    next true if [:Sun, :HarshSun].include?(battler.effectiveWeather) || $game_temp.fieldEffectsBg == 4
  }
)

# MIMICRY

Battle::AbilityEffects::OnSwitchIn.add(:MIMICRY,
  proc { |ability, battler, battle, switch_in|
    # NOTE: Mimicry isn't activated if terrainEffectsBg is lower than 1, which means that it cant be any of the terrains
	# 		which are numbered from 1 to 4.
	# 		I don't know a better way to do this sorry.
    next if $game_temp.terrainEffectsBg < 1 && $game_temp.fieldEffectsBg == 0 # If no Terrain and No Field
    Battle::AbilityEffects.triggerOnTerrainChange(ability, battler, battle, false)
  }
)

Battle::AbilityEffects::OnTerrainChange.add(:MIMICRY,
  proc { |ability, battler, battle, ability_changed|
    if $game_temp.fieldEffectsBg == 0
		if $game_temp.terrainEffectsBg < 1
	  	  # Revert to original typing
		  battle.pbShowAbilitySplash(battler)
		  battler.pbResetTypes
		  battle.pbDisplay(_INTL("{1} changed back to its regular type!", battler.pbThis))
		  battle.pbHideAbilitySplash(battler)
		end
    else
      # Change to new typing
	  checkedTerrainAbility = false
	  case $game_temp.terrainEffectsBg
		when 1 # Grassy Terrain
		  if GameData::Type.exists?(:GRASS)
			new_type = :GRASS
			checkedTerrainAbility = true
		  end
		when 2 # Misty Terrain
		  if GameData::Type.exists?(:FAIRY)
			new_type = :FAIRY
			checkedTerrainAbility = true
		  end
		when 3 # Electric Terrain
		  if GameData::Type.exists?(:ELECTRIC)
			new_type = :ELECTRIC
			checkedTerrainAbility = true
		  end
		when 4 # Psychic Terrain
		  if GameData::Type.exists?(:PSYCHIC)
			new_type = :PSYCHIC
			checkedTerrainAbility = true
		  end
	  end
	 if !checkedTerrainAbility
		case $game_temp.fieldEffectsBg
		  when 1 # Example Field
			new_type = :GRASS
		  when 2 # Volcanic Field
			new_type = :FIRE
		  when 3 # Cave Field
			new_type = :ROCK
		  when 4 # Forest Field
			new_type = :BUG
		  when 5 # Beach Field
			new_type = :GROUND
                  when 6 # Sky Field
			new_type = :FLYING
		  when 7 # City Field
			new_type = :NORMAL
		  when 8 # Garden Field
			new_type = :GRASS
		  when 9 # Slums Field
			new_type = :POISON
		  when 10 # Swarm Field
			new_type = :BUG
		  when 11 # Factory Field
			new_type = :ELECTRIC
                  when 12 # Rave Field
			new_type = :NORMAL
	    end
	 end
      new_type_name = nil
      if new_type
        type_data = GameData::Type.try_get(new_type)
        new_type = nil if !type_data
        new_type_name = type_data.name if type_data
      end
      if new_type
        battle.pbShowAbilitySplash(battler)
        battler.pbChangeTypes(new_type)
        battle.pbDisplay(_INTL("{1}'s type changed to {2}!", battler.pbThis, new_type_name))
        battle.pbHideAbilitySplash(battler)
      end
    end
  }
)

# SURGE SURFER
Battle::AbilityEffects::SpeedCalc.add(:SURGESURFER,
  proc { |ability, battler, mult|
    next mult * 2 if $game_temp.terrainEffectsBg == 3 # Electric Terrain
  }
)

# FLASH FIRE 
Battle::AbilityEffects::DamageCalcFromUser.add(:FLASHFIRE,
  proc { |ability, user, target, move, mults, baseDmg, type|
                                              # VOLCANIC FIELD
    if (user.effects[PBEffects::FlashFire] || $game_temp.fieldEffectsBg == 2) && type == :FIRE
      mults[:attack_multiplier] *= 1.5
    end
  }
)
# FLARE BOOST
Battle::AbilityEffects::DamageCalcFromUser.add(:FLAREBOOST,
  proc { |ability, user, target, move, mults, baseDmg, type|
                        # VOLCANIC FIELD
    if (user.burned? || $game_temp.fieldEffectsBg == 2) && move.specialMove?
      mults[:base_damage_multiplier] *= 1.5
    end
  }
)
# STEAM ENGINE
Battle::AbilityEffects::EndOfRoundEffect.add(:STEAMENGINE,
  proc { |ability, battler, battle|
    next if $game_temp.fieldEffectsBg != 2 # Volcanic Field
    next if battler.airborne?
    battler.pbRaiseStatStageByAbility(:SPEED, 1, battler) if battler.pbCanRaiseStatStage?(:SPEED, battler)
  }
)
# MAGMA ARMOR
Battle::AbilityEffects::OnSwitchIn.add(:MAGMAARMOR,
  proc { |ability, battler, battle, switch_in|
    if $game_temp.fieldEffectsBg == 2 # Volcanic Field
        battler.pbRaiseStatStageByAbility(:DEFENSE, 1, battler)
    end
  }
)

# ICE FACE
Battle::AbilityEffects::OnSwitchIn.add(:ICEFACE,
  proc { |ability, battler, battle, switch_in|
    next if !battler.isSpecies?(:EISCUE) || battler.form != 1
    next if battler.effectiveWeather != :Hail
	next if $game_temp.fieldEffectsBg == 2 # Volcanic Field
    battle.pbShowAbilitySplash(battler)
    if !Battle::Scene::USE_ABILITY_SPLASH
      battle.pbDisplay(_INTL("{1}'s {2} activated!", battler.pbThis, battler.abilityName))
    end
    battler.pbChangeForm(0, _INTL("{1} transformed!", battler.pbThis))
    battle.pbHideAbilitySplash(battler)
  }
)

# ICE FACE
Battle::AbilityEffects::EndOfRoundWeather.add(:ICEFACE,
  proc { |ability, weather, battler, battle|
    next if weather != :Hail
    next if !battler.canRestoreIceFace || battler.form != 1
	next if $game_temp.fieldEffectsBg == 2 # Volcanic Field
    battle.pbShowAbilitySplash(battler)
    if !Battle::Scene::USE_ABILITY_SPLASH
      battle.pbDisplay(_INTL("{1}'s {2} activated!", battler.pbThis, battler.abilityName))
    end
    battler.pbChangeForm(0, _INTL("{1} transformed!", battler.pbThis))
    battle.pbHideAbilitySplash(battler)
  }
)

# DRIZZLE
Battle::AbilityEffects::OnSwitchIn.add(:DRIZZLE,
  proc { |ability, battler, battle, switch_in|
    battle.pbStartWeatherAbility(:Rain, battler)
	if $game_temp.fieldEffectsBg == 2 # Volcanic Field
		$game_temp.fieldEffectsBg = 3 # Cave Field 
		@battle.scene.pbChangeBGSprite
		@battle.pbDisplay(_INTL("The rain snuffed out the flame!"))
	end
  }
)

# SANDSTORM
Battle::AbilityEffects::OnSwitchIn.add(:SANDSTREAM,
  proc { |ability, battler, battle, switch_in|
    battle.pbStartWeatherAbility(:Sandstorm, battler)
	if $game_temp.fieldEffectsBg == 2 # Volcanic Field
		$game_temp.fieldEffectsBg = 3 # Cave Field 
		@battle.scene.pbChangeBGSprite
		@battle.pbDisplay(_INTL("The sand snuffed out the flame!"))
	end
  }
)

# PUNK ROCK
Battle::AbilityEffects::DamageCalcFromUser.add(:PUNKROCK,
  proc { |ability, user, target, move, mults, baseDmg, type|
    if move.soundMove?
		if $game_temp.fieldEffectsBg == 3 # Cave Field
			mults[:attack_multiplier] *= 1.5
		else
			mults[:attack_multiplier] *= 1.3
		end
	end
  }
)

#==================================
# 		ABILITY CHANGES
#==================================
#	5|	STARRYBEACH FIELD

#==================================
# 		ABILITY CHANGES
#==================================

# OWN TEMPO
Battle::AbilityEffects::AccuracyCalcFromTarget.add(:OWNTEMPO,
  proc { |ability, mods, user, target, move, type|
    next if $game_temp.fieldEffectsBg != 5 # StarryBeach Field
    mods[:accuracy_stage] = 0 if move.damagingMove?
  }
)

Battle::AbilityEffects::AccuracyCalcFromUser.add(:OWNTEMPO,
  proc { |ability, mods, user, target, move, type|
    mods[:evasion_stage] = 0 if move.damagingMove?
  }
)

# INNER FOCUS
Battle::AbilityEffects::AccuracyCalcFromTarget.add(:INNERFOCUS,
  proc { |ability, mods, user, target, move, type|
    next if $game_temp.fieldEffectsBg != 5 # StarryBeach Field
    mods[:accuracy_stage] = 0 if move.damagingMove?
  }
)

Battle::AbilityEffects::AccuracyCalcFromUser.add(:INNERFOCUS,
  proc { |ability, mods, user, target, move, type|
    mods[:evasion_stage] = 0 if move.damagingMove?
  }
)

# PURE POWER
Battle::AbilityEffects::AccuracyCalcFromTarget.add(:PUREPOWER,
  proc { |ability, mods, user, target, move, type|
    next if $game_temp.fieldEffectsBg != 5 # StarryBeach Field
    mods[:accuracy_stage] = 0 if move.damagingMove?
  }
)

Battle::AbilityEffects::AccuracyCalcFromUser.add(:PUREPOWER,
  proc { |ability, mods, user, target, move, type|
    mods[:evasion_stage] = 0 if move.damagingMove?
  }
)

# STEADFAST
Battle::AbilityEffects::AccuracyCalcFromTarget.add(:STEADFAST,
  proc { |ability, mods, user, target, move, type|
    next if $game_temp.fieldEffectsBg != 5 # StarryBeach Field
    mods[:accuracy_stage] = 0 if move.damagingMove?
  }
)

Battle::AbilityEffects::AccuracyCalcFromUser.add(:STEADFAST,
  proc { |ability, mods, user, target, move, type|
    mods[:evasion_stage] = 0 if move.damagingMove?
  }
)

# SAND VEIL
Battle::AbilityEffects::AccuracyCalcFromTarget.add(:SANDVEIL,
  proc { |ability, mods, user, target, move, type|
    mods[:evasion_multiplier] *= 1.25 if (target.effectiveWeather == :Sandstorm || $game_temp.fieldEffectsBg == 5) # StarryBeach Field
  }
)

# SAND RUSH
Battle::AbilityEffects::SpeedCalc.add(:SANDRUSH,
  proc { |ability, battler, mult|
    next mult * 2 if ([:Sandstorm].include?(battler.effectiveWeather) || $game_temp.fieldEffectsBg == 5) # StarryBeach Field
  }
)

# SAND FORCE
Battle::AbilityEffects::DamageCalcFromUser.add(:SANDFORCE,
  proc { |ability, user, target, move, mults, baseDmg, type|
    if (user.effectiveWeather == :Sandstorm ||  $game_temp.fieldEffectsBg == 5) && # StarryBeach Field
       [:ROCK, :GROUND, :STEEL].include?(type)
      mults[:base_damage_multiplier] *= 1.3
    end
  }
)

# SAND SPIT
Battle::AbilityEffects::OnBeingHit.add(:SANDSPIT,
  proc { |ability, user, target, move, battle|
    battle.pbStartWeatherAbility(:Sandstorm, target)
	if $game_temp.fieldEffectsBg == 5 # StarryBeach Field
		user.pbLowerStatStageByAbility(:ACCURACY, 1, target, true, true)
	end
  }
)

# WATER COMPACTION
Battle::AbilityEffects::OnBeingHit.add(:WATERCOMPACTION,
  proc { |ability, user, target, move, battle|
    next if move.calcType != :WATER
    target.pbRaiseStatStageByAbility(:DEFENSE, 2, target)
	if $game_temp.fieldEffectsBg == 5 # StarryBeach Field
		target.pbRaiseStatStageByAbility(:SPECIAL_DEFENSE, 2, target)
	end
  }
)

# WATER ABSORB 
Battle::AbilityEffects::EndOfRoundHealing.add(:WATERABSORB,
  proc { |ability, battler, battle|
    next if $game_temp.fieldEffectsBg != 5 # StarryBeach Field
	next if battler.airborne?
    next if !battler.canHeal?
    battler.pbRecoverHP(battler.totalhp / 16)
    battle.pbDisplay(_INTL("{1} restored a little HP!",battler.pbThis))
  }
)

# SAP SIPPER 
Battle::AbilityEffects::EndOfRoundHealing.add(:SAPSIPPER,
  proc { |ability, battler, battle|
    next if $game_temp.fieldEffectsBg != 4 # Forest Field
	next if battler.airborne?
    next if !battler.canHeal?
    battler.pbRecoverHP(battler.totalhp / 16)
    battle.pbDisplay(_INTL("{1} drank tree sap to recover!",battler.pbThis))
  }
)
