# Nero_learnmenu

# Relearn moves handler
MenuHandlers.add(:party_menu, :relearn, {
  "name"      => _INTL("Relearn"),
  "order"     => 36,
  "effect"    => proc { |screen, party, party_idx|
    pbRelearnMoves(party[party_idx], screen)
  }
})

# Improved move relearner function with proper error handling and enhanced moves
def pbRelearnMoves(pkmn, screen)
  begin
    # First check if the Pokemon has any moves to relearn
    if pkmn.species
      species_data = GameData::Species.get(pkmn.species)
      relearnable_moves = []
      
      # Get moves the Pokemon can relearn based on level
      if species_data.moves
        species_data.moves.each do |move_data|
          level, move_id = move_data
          next if level > pkmn.level
          next if pkmn.hasMove?(move_id)
          relearnable_moves.push(move_id)
        end
      end
      
      # Check if there are any moves to relearn
      if relearnable_moves.empty?
        screen.scene.pbDisplay(_INTL("{1} has no moves to relearn.", pkmn.name))
        return
      end
    end
    
    # Try the built-in move relearner implementations
    if defined?(pbMoveRelearnerScreen)
      result = pbMoveRelearnerScreen(pkmn)
      screen.scene.pbHardRefresh
    elsif defined?(pbRelearnMoveScreen)
      result = pbRelearnMoveScreen(pkmn)
      screen.scene.pbHardRefresh
    elsif respond_to?(:pbChooseMoveToRelearn)
      result = pbChooseMoveToRelearn(pkmn)
      screen.scene.pbHardRefresh
    elsif defined?(MoveRelearnerScreen)
      # If it's a class-based system
      result = MoveRelearnerScreen.new(pkmn).pbStartScreen
      screen.scene.pbHardRefresh
    else
      screen.scene.pbDisplay(_INTL("Move relearner is not available."))
    end
    
  rescue NoMethodError => e
    # Handle missing method errors gracefully
    screen.scene.pbDisplay(_INTL("Move relearner system not found."))
  rescue => e
    # Handle any other errors
    screen.scene.pbDisplay(_INTL("Error accessing move relearner: {1}", e.message))
    # Log the full error for debugging
    puts "Move relearner error: #{e.class}: #{e.message}"
    puts e.backtrace.join("\n") if e.backtrace
  end
end