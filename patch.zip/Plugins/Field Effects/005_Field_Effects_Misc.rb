#============================================================================
#
#
#
#============================================================================

#    FIELD EFFECTS IN ORDER OF NUMBER
#
#  1|  Example Field

# NEGATE WEATHER
# NOTE: Here you can make special end of turn damage stuff
# NOTE: Here you can make Entry Hazards deal more damage, or make more things happen.
#    I know how to make Entry Hazard damage be dual-typed for example. I didn't put it in here
#    but if you want I can show how to do it.
class Battle
  def pbWeather
    return :None if allBattlers.any? { |b| b.hasActiveAbility?([:CLOUDNINE, :AIRLOCK]) }
  return :None if $game_temp.fieldEffectsBg == 1 # Example Field
  return :None if @field.weather == :Hail && $game_temp.fieldEffectsBg == 2 # Volcanic Field 
    return @field.weather
  end

  # Used for causing weather by a move or by an ability.
  def pbStartWeather(user, newWeather, fixedDuration = false, showAnim = true)
    return if @field.weather == newWeather
    @field.weather = newWeather
    duration = (fixedDuration) ? 5 : -1
    if duration > 0 && user && user.itemActive?
      duration = Battle::ItemEffects.triggerWeatherExtender(user.item, @field.weather,
                                                            duration, user, self)
    end
  case @field.weather
    when :Sandstorm
      if $game_temp.fieldEffectsBg == 5 # Starry Beach Field
        @field.weatherDuration = 8
      end
  end 
    @field.weatherDuration = duration
    weather_data = GameData::BattleWeather.try_get(@field.weather)
    pbCommonAnimation(weather_data.animation) if showAnim && weather_data
    pbHideAbilitySplash(user) if user
    case @field.weather
    when :Sun         then pbDisplay(_INTL("The sunlight turned harsh!"))
    when :Rain        then pbDisplay(_INTL("It started to rain!"))
    when :Sandstorm   then pbDisplay(_INTL("A sandstorm brewed!"))
    when :Hail        then pbDisplay(_INTL("It started to hail!"))
    when :HarshSun    then pbDisplay(_INTL("The sunlight turned extremely harsh!"))
    when :HeavyRain   then pbDisplay(_INTL("A heavy rain began to fall!"))
    when :StrongWinds then pbDisplay(_INTL("Mysterious strong winds are protecting Flying-type Pokémon!"))
    when :ShadowSky   then pbDisplay(_INTL("A shadow sky appeared!"))
    end
    # Check for end of primordial weather, and weather-triggered form changes
    allBattlers.each { |b| b.pbCheckFormOnWeatherChange }
    pbEndPrimordialWeather
  end

  #=============================================================================
  # End Of Round various healing effects
  #=============================================================================
  def pbEORHealingEffects(priority)
    # Aqua Ring
    priority.each do |battler|
      next if !battler.effects[PBEffects::AquaRing]
      next if !battler.canHeal?
    #if $game_temp.fieldEffectsBg == 5  || $game_temp.fieldEffectsBg == 6 # Water Surface Field - Underwater Field
    #hpGain = battler.totalhp / 8
    #else
    hpGain = battler.totalhp / 16
    #end
      hpGain = (hpGain * 1.3).floor if battler.hasActiveItem?(:BIGROOT)
      battler.pbRecoverHP(hpGain)
      pbDisplay(_INTL("Aqua Ring restored {1}'s HP!", battler.pbThis(true)))
    end
    # Ingrain
    priority.each do |battler|
      next if !battler.effects[PBEffects::Ingrain]
      next if !battler.canHeal?
    if $game_temp.fieldEffectsBg == 4 || [:Sun, :HarshSun].include?(battler.effectiveWeather) # Forest Field
    hpGain = battler.totalhp / 8
    else
    hpGain = battler.totalhp / 16
    end
      hpGain = (hpGain * 1.3).floor if battler.hasActiveItem?(:BIGROOT) 
      battler.pbRecoverHP(hpGain)
      pbDisplay(_INTL("{1} absorbed nutrients with its roots!", battler.pbThis))
    end
    # Leech Seed
    priority.each do |battler|
      next if battler.effects[PBEffects::LeechSeed] < 0
      next if !battler.takesIndirectDamage?
      recipient = @battlers[battler.effects[PBEffects::LeechSeed]]
      next if !recipient || recipient.fainted?
      pbCommonAnimation("LeechSeed", recipient, battler)
      battler.pbTakeEffectDamage(battler.totalhp / 8) { |hp_lost|
        recipient.pbRecoverHPFromDrain(hp_lost, battler,
                                       _INTL("{1}'s health is sapped by Leech Seed!", battler.pbThis))
        recipient.pbAbilitiesOnDamageTaken
      }
      recipient.pbFaint if recipient.fainted?
    end
  end
  
  #=============================================================================
  # End Of Round deal damage to trapped battlers
  #=============================================================================
  TRAPPING_MOVE_COMMON_ANIMATIONS = {
    :BIND        => "Bind",
    :CLAMP       => "Clamp",
    :FIRESPIN    => "FireSpin",
    :MAGMASTORM  => "MagmaStorm",
    :SANDTOMB    => "SandTomb",
    :WRAP        => "Wrap",
    :INFESTATION => "Infestation"
  }

  def pbEORTrappingDamage(battler)
    return if battler.fainted? || battler.effects[PBEffects::Trapping] == 0
    battler.effects[PBEffects::Trapping] -= 1
    move_name = GameData::Move.get(battler.effects[PBEffects::TrappingMove]).name
    if battler.effects[PBEffects::Trapping] == 0
      pbDisplay(_INTL("{1} was freed from {2}!", battler.pbThis, move_name))
      return
    end
    anim = TRAPPING_MOVE_COMMON_ANIMATIONS[battler.effects[PBEffects::TrappingMove]] || "Wrap"
    pbCommonAnimation(anim, battler)
    return if !battler.takesIndirectDamage?
    hpLoss = (Settings::MECHANICS_GENERATION >= 6) ? battler.totalhp / 8 : battler.totalhp / 16
    if @battlers[battler.effects[PBEffects::TrappingUser]].hasActiveItem?(:BINDINGBAND)
      hpLoss = (Settings::MECHANICS_GENERATION >= 6) ? battler.totalhp / 6 : battler.totalhp / 8
    end
    # NOTE: Follow the example under this if you desire to make Trapping moves deal more damage
    #     There are ways to make Binding Band + Field Damage Boost work together. But I think thats overkill.
    if $game_temp.fieldEffectsBg == 10 && battler.effects[PBEffects::TrappingMove] == :INFESTATION #Swarm Field
      hpLoss = battler.totalhp / 6
    end
    @scene.pbDamageAnimation(battler)
    battler.pbTakeEffectDamage(hpLoss, false) { |hp_lost|
      pbDisplay(_INTL("{1} is hurt by {2}!", battler.pbThis, move_name))
    }
  end

  def pbEOREffectDamage(priority)
    # Damage from sleep (Nightmare)
    priority.each do |battler|
      battler.effects[PBEffects::Nightmare] = false if !battler.asleep?
      next if !battler.effects[PBEffects::Nightmare] || !battler.takesIndirectDamage?
      battler.pbTakeEffectDamage(battler.totalhp / 4) { |hp_lost|
      pbDisplay(_INTL("{1} is locked in a nightmare!", battler.pbThis))
      }
    end
    # Curse
    priority.each do |battler|
      next if !battler.effects[PBEffects::Curse] || !battler.takesIndirectDamage?
      battler.pbTakeEffectDamage(battler.totalhp / 4) { |hp_lost|
      pbDisplay(_INTL("{1} is afflicted by the curse!", battler.pbThis))
      }
    end
    # Volcanic Field Damage
    priority.each do |battler|
      next if $game_temp.fieldEffectsBg != 2 || !battler.takesIndirectDamage?
      next if battler.effects[PBEffects::AquaRing] == true
      next if battler.hasActiveAbility?(:MAGMAARMOR) || 
              battler.hasActiveAbility?(:FLAMEBODY) || 
          battler.hasActiveAbility?(:FLASHFIRE) ||
          battler.hasActiveAbility?(:FLAREBOOST) ||
          battler.hasActiveAbility?(:WATERVEIL) ||
          battler.hasActiveAbility?(:HEATPROOF) ||
          battler.hasActiveAbility?(:LEVITATE) 
      next if battler.pbHasType?(:FIRE) || battler.pbHasType?(:FLYING)
      if battler.hasActiveAbility?(:FLUFFY) || 
         battler.hasActiveAbility?(:ICEBODY) || 
       battler.hasActiveAbility?(:LEAFGUARD) || 
       battler.hasActiveAbility?(:GRASSPELT)
      if battler.effects[PBEffects::TarShot] == true
        battler.pbTakeEffectDamage(battler.totalhp / 2) { |hp_lost|
        pbDisplay(_INTL("The tar causes {1} to burn even more!", battler.pbThis))
        }
      else
      battler.pbTakeEffectDamage(battler.totalhp / 4) { |hp_lost|
        pbDisplay(_INTL("{1} is burning!", battler.pbThis))
        }
      end
      else
      if battler.effects[PBEffects::TarShot] == true
        battler.pbTakeEffectDamage(battler.totalhp / 4) { |hp_lost|
        pbDisplay(_INTL("The tar causes {1} to burn even more!", battler.pbThis))
        }
      else
        battler.pbTakeEffectDamage(battler.totalhp / 8) { |hp_lost|
        pbDisplay(_INTL("{1} was burned by the field!", battler.pbThis))
        }
      end
      end
    end
  end

  def pbEntryHazards(battler)
    battler_side = battler.pbOwnSide
	# Swarm Field
	if $game_temp.fieldEffectsBg == 10 && !battler.types.include?(:BUG) && !battler.fainted? && !battler.airborne? && !battler.hasActiveItem?(:HEAVYDUTYBOOTS)
      pbDisplay(_INTL("{1} was caught in the swarm!", battler.pbThis))
      if battler.pbCanLowerStatStage?(:SPEED)
        battler.pbLowerStatStage(:SPEED, 1, nil)
        battler.pbItemStatRestoreCheck
      end
	end
    # Stealth Rock
    if battler_side.effects[PBEffects::StealthRock] && battler.takesIndirectDamage? &&
       GameData::Type.exists?(:ROCK) && !battler.hasActiveItem?(:HEAVYDUTYBOOTS)
      bTypes = battler.pbTypes(true)
      eff = Effectiveness.calculate(:ROCK, bTypes[0], bTypes[1], bTypes[2])      
      if !Effectiveness.ineffective?(eff)
      eff = eff.to_f / Effectiveness::NORMAL_EFFECTIVE
      if $game_temp.fieldEffectsBg == 3 # Cave Field
        battler.pbReduceHP(battler.totalhp * eff / 4, false)
      else  
        battler.pbReduceHP(battler.totalhp * eff / 8, false)
      end
      pbDisplay(_INTL("Pointed stones dug into {1}!", battler.pbThis))
      battler.pbItemHPHealCheck
      end
    end
    # Spikes
    if battler_side.effects[PBEffects::Spikes] > 0 && battler.takesIndirectDamage? &&
       !battler.airborne? && !battler.hasActiveItem?(:HEAVYDUTYBOOTS)
      spikesDiv = [8, 6, 4][battler_side.effects[PBEffects::Spikes] - 1]
      battler.pbReduceHP(battler.totalhp / spikesDiv, false)
      pbDisplay(_INTL("{1} is hurt by the spikes!", battler.pbThis))
      battler.pbItemHPHealCheck
    end
    # Toxic Spikes
    if battler_side.effects[PBEffects::ToxicSpikes] > 0 && !battler.fainted? && !battler.airborne?
      if battler.pbHasType?(:POISON)
      battler_side.effects[PBEffects::ToxicSpikes] = 0
      pbDisplay(_INTL("{1} absorbed the poison spikes!", battler.pbThis))
      elsif battler.pbCanPoison?(nil, false) && !battler.hasActiveItem?(:HEAVYDUTYBOOTS)
      if battler_side.effects[PBEffects::ToxicSpikes] == 2
        battler.pbPoison(nil, _INTL("{1} was badly poisoned by the poison spikes!", battler.pbThis), true)
      else
        battler.pbPoison(nil, _INTL("{1} was poisoned by the poison spikes!", battler.pbThis))
      end
      end
    end
    # Sticky Web
    if battler_side.effects[PBEffects::StickyWeb] && !battler.fainted? && !battler.airborne? && !battler.hasActiveItem?(:HEAVYDUTYBOOTS)
      pbDisplay(_INTL("{1} was caught in a sticky web!", battler.pbThis))
      if battler.pbCanLowerStatStage?(:SPEED)
        if $game_temp.fieldEffectsBg == 10 # Swarm Field
        battler.pbLowerStatStage(:SPEED, 2, nil)
      else
        battler.pbLowerStatStage(:SPEED, 1, nil)
      end
      battler.pbItemStatRestoreCheck
      end
    end
  end
#=============================================================================
# End Of Round healing from Terrains or Fields
#=============================================================================
  def pbEORTerrainHealing(battler)
    return if battler.fainted?
    # Grassy Terrain (healing)
    if $game_temp.terrainEffectsBg == 1 && battler.affectedByTerrain? && battler.canHeal?
      PBDebug.log("[Lingering effect] Grassy Terrain heals #{battler.pbThis(true)}")
      battler.pbRecoverHP(battler.totalhp / 16)
      pbDisplay(_INTL("{1}'s HP was restored.", battler.pbThis))
    end
  end
end

# BUG TYPE SPEED BOOST ON [ EXAMPLE FIELD ]
# STATUS IMMUNITY - GENERAL
# CONFUSION IMMUNITY
# PRIORITY MOVES DON'T WORK
class Battle::Battler
  alias fieldEffectsSpeed_pbSpeed pbSpeed
  alias terrainEffects_pbCanInflictStatus? pbCanInflictStatus?
  alias terrainEffects_pbCanConfuse? pbCanConfuse?
  alias terrainEffects_pbSuccessCheckAgainstTarget  pbSuccessCheckAgainstTarget

  def pbSpeed
    ret = fieldEffectsSpeed_pbSpeed
    ret *= 1.2 if pbHasType?(:BUG) && $game_temp.fieldEffectsBg == 1 # Example Field
    ret /= 2 if (!pbHasType?(:WATER) || !hasActiveAbility?(:SWIFTSWIM) || !hasActiveAbility?(:SURGESURFER) || !hasActiveAbility?(:STEELWORKER)) && $game_temp.fieldEffectsBg == 1 # Example Field
    # Calculation
    return ret
  end

  def pbCanInflictStatus?(newStatus, user, showMessages, move = nil, ignoreStatus = false)
    ret = terrainEffects_pbCanInflictStatus?(newStatus, user, showMessages, move, ignoreStatus)
    if ret 
      # Terrains immunity
      if affectedByTerrain?
        case $game_temp.terrainEffectsBg 
          when 2 # Misty Terrain
          @battle.pbDisplay(_INTL("{1} surrounds itself with misty terrain!", pbThis(true))) if showMessages
          return false
          when 3 # Electric Terrain
          if newStatus == :SLEEP
             @battle.pbDisplay(_INTL("{1} surrounds itself with electrified terrain!", pbThis(true))) if showMessages
             return false
          end
        end
      end
        # Field Immunity
      case $game_temp.fieldEffectsBg
        when 2 # Volcanic Field
          if newStatus == :FROZEN
            if showMessages
            @battle.pbDisplay(_INTL("The heat protected {1} from being frozen!", pbThis(true))) if showMessages
            return false
            end
          end
      end
    end
    return ret
  end

  def pbCanConfuse?(user = nil, showMessages = true, move = nil, selfInflicted = false)
    ret = terrainEffects_pbCanConfuse?(user, showMessages, move, selfInflicted)
    if ret
      # Terrains immunity
      if affectedByTerrain?
        case $game_temp.terrainEffectsBg 
          when 2 # Misty Terrain
          @battle.pbDisplay(_INTL("{1} surrounds itself with misty terrain!", pbThis(true))) if showMessages
          return false
        end
      end
      if pbHasType?(:FIGHTING) && $game_temp.fieldEffectsBg == 5 # Starry Beach Field
        return false
      end
    else
      return false
    end
  end

  def pbSuccessCheckAgainstTarget(move, user, target, targets)
    ret = terrainEffects_pbSuccessCheckAgainstTarget(move, user, target, targets)
    if ret
      return true
    else
      # Immunity to priority moves because of Psychic Terrain
        if $game_temp.terrainEffectsBg == 4 && target.affectedByTerrain? && target.opposes?(user) &&
           @battle.choices[user.index][4] > 0   # Move priority saved from pbCalculatePriority
           @battle.pbDisplay(_INTL("{1} surrounds itself with psychic terrain!", target.pbThis)) if show_message
          return false
      end
    end
  end
end

# DUAL-TYPE MOVES & CHANGE TYPE EFFECTIVENESS
class Battle::Move
  alias fieldEffects_pbCalcTypeModSingle pbCalcTypeModSingle
 
  def fieldEffects_pbCalcTypeModSingle(moveType, defType, user, target)
    case $game_temp.fieldEffectsBg
      when 1 # Example Field
        # This one causes  Rock Type Moves to become Rock/Water
        # What we are doing is changing type effectiveness of Rock Moves, so the game calculates it as dual typed
        if GameData::Type.exists?(:WATER) && moveType == :ROCK  
          waterEff = Effectiveness.calculate_one(:WATER, defType)
          ret *= waterEff.to_f / Effectiveness::NORMAL_EFFECTIVE_ONE
        end
        # This one here makes Water Moves deal Neutral Damage against Water Pokemon
        if defType == :WATER && moveType == :WATER  
          ret = Effectiveness::NORMAL_EFFECTIVE_ONE
        end
    end
  pbCalcTypeModSingle
  end  
end
