import os
import subprocess

# Get the current directory where the script is located
script_dir = os.path.dirname(os.path.abspath(__file__))

# Define the path to the pngcrush executable
pngcrush_path = "C:\\Users\\Lcorp\\Downloads\\pngcrush_1_8_11_w64.exe"  # Replace with the actual path

# Change directory to the folder containing the images
os.chdir(script_dir)

# List all files in the current directory
files = os.listdir()

# Supported image file formats
supported_formats = (".png")

# Loop through the files in the current directory
for file in files:
    if file.lower().endswith(supported_formats):
        try:
            # Use pngcrush with the overwrite (-ow) argument to remove the iCCP profile
            subprocess.run([pngcrush_path, "-rem", "iCCP", "-ow", file])
            print(f"Removed iCCP profile from {file}")
        except Exception as e:
            print(f"Error processing {file}: {str(e)}")
    else:
        print(f"Skipped {file} (unsupported format)")

print("iCCP profile removal complete.")
