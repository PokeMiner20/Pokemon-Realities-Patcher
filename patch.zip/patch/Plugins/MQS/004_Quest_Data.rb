module QuestModule
  
  # You don't actually need to add any information, but the respective fields in the UI will be blank or "???"
  # I included this here mostly as an example of what not to do, but also to show it's a thing that exists
  Quest0 = {
  
  }
  
  # Here's the simplest example of a single-stage quest with everything specified
  Quest1 = {
    :ID => "1",
    :Name => "Identity Crisis",
    :QuestGiver => "Yourself",
    :Stage1 => "Find a Student ID.",
    :Stage2 => "Go use the Student ID.",
    :Location1 => "Night Market",
    :Location2 => "Meliosant University",
	:StageLabel1 => "1",
	:StageLabel2 => "2",
    :QuestDescription => "You need a Student ID to enter the library, go find one!",
    :RewardString => "A lot of knowledge"
  }
  
  # Here's an extension of the above that includes multiple stages
 Quest2 = {
    :ID => "2",
    :Name => "Missing Scientist",
    :QuestGiver => "Professor Milton",
    :Stage1 => "Head to Newport Town and ask around for clues.",
    :Stage2 => "Find the warehouse key.",
    :Stage3 => "Head to the warehouse next to the lighthouse.",
    :Stage4 => "Rescue the scientist!",
    :Stage5 => "Report to Milton.",
    :Location1 => "Newport Town",
    :Location2 => "Newport Town",
    :Location3 => "Newport Docks",
    :Location4 => "Docks Warehouse",
    :Location5 => "Laboratory (Main)",
    :QuestDescription => "One of Milton's scientist's has been missing since the Newport raid, go look for them.",
    :RewardString => "Something Powerful..."
  }
  
  # Here's an example of a quest with lots of stages that also doesn't have a stage location defined for every stage
  Quest3 = {
    :ID => "3",
    :Name => "Golden Silk",
    :QuestGiver => "Orla",
    :Stage1 => "Head to Goldenweb Cave",
    :Stage2 => "Obtain the Golden Silk",
    :Stage3 => "Return to Orla with the Silk",
    :Location1 => "Silk Forest",
    :Location2 => "Goldenweb Cave",
    :Location3 => "Meliosant City",
    :QuestDescription => "Gotta keep up with fashion!",
    :RewardString => "Something Special"
  }

    Quest4 = {
    :ID => "4",
    :Name => "Fishing Time",
    :QuestGiver => "Fisherman",
    :Stage1 => "Find the rod",
    :Stage2 => "Return the rod",
    :Location1 => "Route 1",
    :Location2 => "Newport Town",
    :QuestDescription => "Find and return the fishing rod to the fisherman.",
    :RewardString => "Something Valuable"
  }

  Quest5 = {
    :ID => "5",
    :Name => "Save the Pokemon",
    :QuestGiver => "Zero",
    :Stage1 => "Save the pokemon",
    :Location1 => "Meliosant Slums",
    :QuestDescription => "Save the Pokemon that are being sold in the slums.",
    :RewardString => "Pokemon"
  }
  # Here's an example of not defining the quest giver and reward text
  Quest6 = {
    :ID => "6",
    :Name => "The Legendary Pig",
    :QuestGiver => "Old Man",
    :Stage1 => "Find the pig.",
    :Stage2 => "Show the old man.",
    :Location1 => "Route 1",
    :Location2 => "Laboratory",
    :QuestDescription => "The old man tells you about a legendary pig, go find it!",
    :RewardString => "An egg?"
  }
  
  # Other random examples you can look at if you want to fill out the UI and check out the page scrolling
  Quest7 = {
    :ID => "7",
    :Name => "Althesea's Wish",
    :QuestGiver => "Althesea",
    :Stage1 => "Go buy flowers for her parent's graves.",
    :Stage2 => "Return to Althesea with the flowers.",
    :Location1 => "Night Market",
    :Location2 => "Lutherfield Garden",
    :QuestDescription => "Althesea wants to you to buy flowers for her parent's graves.",
    :RewardString => "Althesea's Gratitude."
  }

  Quest8 = {
    :ID => "8",
    :Name => "Helpless Granny",
    :QuestGiver => "Grandma",
    :Stage1 => "Help Grandma get home safely.",
    :Location1 => "Meliosant City",
    :QuestDescription => "Help Grandma to her destination safely.",
    :RewardString => "Grandma's Treat"
  }

  Quest9 = {
    :ID => "9",
    :Name => "A Fisherman's Desire",
    :QuestGiver => "Fisherman",
    :Stage1 => "Go to Newport Town.",
    :Stage2 => "Take a photo of the ocean.",
    :Stage3 => "Return to the Fisherman",
    :Location1 => "Newport Town",
    :Location2 => "Newport Town",
    :Location3 => "Meliosant City",
    :QuestDescription => "A fisherman moved to the city, and misses the sound of the ocean.",
    :RewardString => "Ocean's Scenery"
  }

 Quest10 = {
    :ID => "10",
    :Name => "Runaway Pokemon",
    :QuestGiver => "Wise Man",
    :Stage1 => "Find the runaway Pokemon.",
    :Stage2 => "Return the Pokemon to the man.",
    :Location1 => "Meliosant City",
    :Location2 => "Laboratory",
    :QuestDescription => "The man lost his Pokemon and is demanding you find them for him.",
    :RewardString => "Whatever he feels like giving you"
  }

 Quest11 = {
    :ID => "11",
    :Name => "Noisy Neighbor",
    :QuestGiver => "Green Dress Lady",
    :Stage1 => "Stop the noisy resident.",
    :Location1 => "Meliosant City",
    :QuestDescription => "Someone's being noisy, go ask them to keep it down.",
    :RewardString => "???"
  }

 Quest12 = {
    :ID => "12",
    :Name => "An item from the Future",
    :QuestGiver => "Hoverboard",
    :Stage1 => "Find a Mechanic.",
    :Stage2 => "Go to the Mechanic's Shop.",
    :Location1 => "Meliosant City",
    :Location2 => "Night Market",
    :QuestDescription => "You found a transportation device from the future, however it seems broken and needs fixing.",
    :RewardString => "Transportation from the Future!"
  }
end