#===============================================================================
#
#===============================================================================
class PokemonTrainerCard_Scene
  def pbStartScene
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites = {}
    gender_suffix = (($player.male?) ? "" : (($player.female?) ? "_f" : "_nb"))
    background = pbResolveBitmap(sprintf("Graphics/Pictures/Trainer Card/bg#{gender_suffix}"))
    addBackgroundPlane(@sprites, "bg", "Trainer Card/bg#{gender_suffix}", @viewport)
    @sprites["card"] = IconSprite.new(0, 0, @viewport)
    @sprites["card"].setBitmap("Graphics/Pictures/Trainer Card/card#{gender_suffix}")
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    pbSetSystemFont(@sprites["overlay"].bitmap)
    @sprites["trainer"] = IconSprite.new(336, 112, @viewport)
    @sprites["trainer"].setBitmap(GameData::TrainerType.player_front_sprite_filename($player.trainer_type))
    @sprites["trainer"].x -= (@sprites["trainer"].bitmap.width - 128) / 2
    @sprites["trainer"].y = 88
    @sprites["trainer"].z = 2
    pbDrawTrainerCardFront
    pbFadeInAndShow(@sprites) { pbUpdate }
  end
end
