#============================================================================
#
#
#
#============================================================================

#        FIELD EFFECTS IN ORDER OF NUMBER
#
#    1|    Example Field

#=================================
#             POWER BOOSTS
#=================================

class Battle::Move
  alias fieldEffects_pbCalcDamageMultipliers pbCalcDamageMultipliers
  def pbCalcDamageMultipliers(user,target,numTargets,type,baseDmg,multipliers)
    # GENERAL BOOSTS
    case $game_temp.terrainEffectsBg
      when 1 # Grassy Terrain
      # BOOSTS #
      if type == :GRASS && user.affectedByTerrain?
        multipliers[:base_damage_multiplier] *= 1.3
        @battle.pbDisplay(_INTL("The grass strengthened the attack!"))
      end
      # DEBUFF #
        if [:BULLDOZE, :EARTHQUAKE, :MAGNITUDE].include?(@id) && target.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The soil absorbed the attack!"))
        end 
      when 2 # Misty Terrain
        # BOOSTS
      if specialMove? && target.pbHasType?(:FAIRY)
        multipliers[:defense_multiplier] *= 1.3
      end
        # DEBUFFS
        if type == :DRAGON && target.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The draconic power weakened...")) #if $game_temp.fieldMessage==0
        end
      when 3 # Electric Terrain
        # BOOSTS
        if type == :ELECTRIC
          multipliers[:base_damage_multiplier] *= 1.3
          @battle.pbDisplay(_INTL("The charged terrain powered up the attack!")) #if $game_temp.fieldMessage==0
        end
      when 4 # Psychic Terrain
        # BOOSTS
        if type == :PSYCHIC && user.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 1.3
          @battle.pbDisplay(_INTL("The weirdness boosted the attack!")) #if $game_temp.fieldMessage==0
        end
        # DEBUFFS
    end

    case $game_temp.fieldEffectsBg
      when 1 # Example Field
        # TYPE EFFECTS
        if type == :NORMAL
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The example field strengthened the attack!")) #if $game_temp.fieldMessage==0
          #$game_temp.fieldMessage += 1
        end
        if type == :PSYCHIC && physicalMove?
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The attack gets all beefed up!")) #if $game_temp.fieldMessage==0
          #$game_temp.fieldMessage += 1
        end
        if contactMove?
          multipliers[:base_damage_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("The contact move got powered up!")) #if $game_temp.fieldMessage==0
          #$game_temp.fieldMessage += 1
        end
        if !contactMove?
          multipliers[:base_damage_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("The non-contact move went super sayan!")) #if $game_temp.fieldMessage==0
          #$game_temp.fieldMessage += 1
        end
        if soundMove?
          multipliers[:base_damage_multiplier] *= 1.1
          @battle.pbDisplay(_INTL("Echo...echo...echo..."))
        end
        if type == :GRASS && user.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The move got weaker cause the user is touching grass (literally)!")) #if $game_temp.fieldMessage==0
        end
        if type == :FIRE && target.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The enemy is touching grass, which makes the move weaker!")) 
        end

        # MOVE BOOSTS
        if @id == :HURRICANE
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("Multiple trees fell on {1}!",target.pbThis(true)))
        end
        if [:CUT, :PSYCHOCUT, :FURYCUTTER].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("A tree fell onto {1}!",target.pbThis(true)))
        end 
        # MOVE DEBUFFS
        if [:SURF, :MUDDYWATER, :ROCKTHROW].include?(@id)
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The attack got weaker!"))
        end 
      when 2 # Volcanic Field
        # TYPE EFFECTS
        if type == :FIRE && user.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The blaze amplified the attack!")) 
        end
        if type == :GRASS && target.affectedByTerrain?
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The blaze softened the attack...")) 
        end
        if type == :ICE 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The blaze softened the attack...")) 
        end

        # MOVE BOOSTS
         if [:SMOG, :CLEARSMOG].include?(@id)
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("The flames spread from the attack!"))
        end
        # MOVE TRANSFORMATION BOOSTS
        if [:GUST,:RAZORWIND,:HURRICANE].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.3
        end
        if [:SURF, :MUDDYWATER, :WATERSPORT, :WATERPLEDGE, :WATERSPOUT, :SPARKLINGARIA, :HYDROVORTEX, :OCEANICOPERRATA].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.3
        end
        if [:SANDTOMB,:BLIZZARD].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.3
        end
      when 3 # Cave Field
        # TYPE EFFECTS
        if type == :ROCK
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The cavern strengthened the attack!")) #if $game_temp.fieldMessage==0
          #$game_temp.fieldMessage += 1
        end
        if type == :FLYING && !contactMove?
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The cave choked out the air...")) #if $game_temp.fieldMessage==0
          #$game_temp.fieldMessage += 1
        end

        # MOVE BOOSTS
        if [:ROCKTOMB].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("...Piled on!"))
        end
        if soundMove?
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("ECHO-Echo-echo!"))
        end
        # MOVE TRANSFORMATION BOOSTS
        if [:ERUPTION,:LAVAPLUME,:HEATWAVE,:OVERHEAT,:FUSIONFLARE].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.3
        end
      when 4 # Forest Field
        # TYPE EFFECTS
        if type == :GRASS
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The forestry strengthened the attack!")) 
        end
        if type == :BUG
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The attack spreads through the forest!"))
        end
        # MOVE BOOSTS
        if @id == :CUT
            multipliers[:base_damage_multiplier] *= 2
            @battle.pbDisplay(_INTL("A tree fell onto {1}!",target.pbThis(true)))
        end
        if [:SLASH,:AIRSLASH,:BUGBITE,:FURYCUTTER,:BUGBUZZ,:PSYCHOCUT,:INFESTATION].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("They're coming out of the woodwork!"))
        end
        if @id == :ATTACKORDER
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("The wild bugs joined the attack!"))
        end
        if @id == :GRAVAPPLE
          multipliers[:base_damage_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("An apple fell from the tree!"))
        end
        # MOVE DEBUFF
        if [:SURF, :MUDDYWATER].include?(@id)
          ultipliers[:base_damage_multiplier] *= 0.5
          battle.pbDisplay(_INTL("The forest softened the attack..."))
        end 
      when 5 # Beach Field
        # MOVE BOOSTS
        if [:MUDSLAP,:MUDSHOT,:MUDBOMB,:SANDTOMB].include?(@id)
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("Ash mixed into the attack!"))
        end
        if @id == :HIDDENPOWER
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("...And with pure focus!"))
        end
        if [:SURF,:MUDDYWATER].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("Surf's up!"))
        end
        if [:THOUSANDWAVES,:LANDSWRATH].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The sand strengthened the atttack!"))
        end
        if [:ZENHEADBUTT,:STOREDPOWER,:AURASPHERE,:FOCUSBLAST].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.3
          @battle.pbDisplay(_INTL("...And with full focus...!"))
        end
        if @id == :PSYCHIC
          multipliers[:base_damage_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("...And with focus...!"))
        end
        if @id == :STRENGTH
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("...And with pure focus!"))
        end
      when 6 # Sky Field
        # TYPE EFFECTS
        if type == :FLYING
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The wind strengthened the attack!")) 
        end
        # MOVE BOOSTS
        if [:HURRICANE,:GUST,:AIRSLASH,:AIRCUTTER].include?(@id)
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("The wind strengthened the attack!"))
        end
        if @id == :HIDDENPOWER
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("...Ride like the wind!"))
        end
        if [:TWISTER,:HURRICANE].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("Tornado!"))
        end
        if [:AERIALACE,:ARCOBATICS].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The wind strengthened the attack!"))
        end
        if [:WINGATTACK,:BRAVEBIRD,:BOUNCE,:FLY].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.3
          @battle.pbDisplay(_INTL("...And with full focus...!"))
        end
        # MOVE DEBUFFS
		if type == :ROCK 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The wind weakened the attack..."))
          multipliers[:base_damage_multiplier] *= 0.5
        end
        if type == :GROUND 
          multipliers[:base_damage_multiplier] *= 0.2
          @battle.pbDisplay(_INTL("You're not on the ground anymore..."))
          multipliers[:base_damage_multiplier] *= 0.2
        end
      when 7 # City Field
        # TYPE EFFECTS
        if type == :NORMAL
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The bustle of the city streets!"))
        end
        if type == :FAIRY
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The myths of the city strike!"))
        end
       # MOVE DEBUFFS
		if type == :POISON 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("Not on these streets!"))
          multipliers[:base_damage_multiplier] *= 0.5
        end
      when 8 # Garden Field
        if type == :GRASS
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The plants help the attack!"))
        end
        if type == :FIRE
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The flames burn the forest!"))
        end
        # MOVE BOOSTS
        if @id == :SOLARBEAM
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("The plants increased its power!"))
        end
        if @id == :GRAVAPPLE
          multipliers[:base_damage_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("An apple fell from the tree!"))
       end
        # MOVE DEBUFFS
		if type == :WATER 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The grass absorbed the attack..."))
          multipliers[:base_damage_multiplier] *= 0.5
        end
      when 9 # Slums Field
        # TYPE EFFECTS
        if type == :DARK
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The slum shadows assist the attack!"))
        end
        # MOVE BOOSTS
        if @id == :BITE
            multipliers[:base_damage_multiplier] *= 2
            @battle.pbDisplay(_INTL("The bite became more aggressive!"))
        end
        if @id == :CRUNCH
            multipliers[:base_damage_multiplier] *= 1.5
            @battle.pbDisplay(_INTL("The bite became more aggressive!"))
        end
        if [:CROSSPOISON,:GUNKSHOT,:SLUDGEBOMB,:SLUDGEWAVE,:POISONJAB,:POISONTAIL,:POISONSTING,:VENOSHOCK].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The gunk and garbage attacks also!"))
       # MOVE DEBUFFS
		if type == :Grass 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The grass became contaminated..."))
          multipliers[:base_damage_multiplier] *= 0.5
        end
end
      when 10 # Swarm Field
        # TYPE EFFECTS
        if target.types.include?(:BUG)
          multipliers[:defense_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("A swarm protects {1}!", target.pbThis))
        end
        if type == :BUG
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The attack spreads through the forest!"))
        end
        # MOVE BOOSTS
        if @id == :CUT
            multipliers[:base_damage_multiplier] *= 2
            @battle.pbDisplay(_INTL("A tree fell onto {1}!",target.pbThis(true)))
        end
        if [:SLASH,:AIRSLASH,:BUGBITE,:FURYCUTTER,:BUGBUZZ,:PSYCHOCUT,:INFESTATION].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("They're coming out of the woodwork!"))
        end
        if @id == :ATTACKORDER
          multipliers[:base_damage_multiplier] *= 2
          @battle.pbDisplay(_INTL("The wild bugs joined the attack!"))
        end
        if @id == :GRAVAPPLE
          multipliers[:base_damage_multiplier] *= 1.2
          @battle.pbDisplay(_INTL("An apple fell from the tree!"))
       end
        # MOVE DEBUFFS
		if type == :WATER 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The swarm softened the attack..."))
          multipliers[:base_damage_multiplier] *= 0.5
        end
      when 11 # Factory Field
        # TYPE EFFECTS
        if type == :ELECTRIC
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("BZZT!"))
        if type == :STEEL
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The bolts are going nuts!"))
        end
       # MOVE DEBUFFS
		if type == :ROCK 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The rocks got jammed in the gears..."))
          multipliers[:base_damage_multiplier] *= 0.5
         end
     if [:AIRSLASH,:AIRCUTTER,:FLY,:HURRICANE,:TWISTER,:GUST].include?(@id)
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The factory messed up the attack!"))
        end
end
      when 12 # Rave Field
       # TYPE EFFECTS
        if type == :NORMAL
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("The melody carried the attack!"))
        end
        # MOVE BOOSTS
        if [:FOCUSPUNCH,:PSYSHIELDBASH,:PSYCHOCUT].include?(@id)
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("Give the crowd a show!"))
        end
        if soundMove?
          multipliers[:base_damage_multiplier] *= 1.5
          @battle.pbDisplay(_INTL("Echo...echo...echo..."))
        end
        # MOVE DEBUFFS
		if type == :DARK 
          multipliers[:base_damage_multiplier] *= 0.5
          @battle.pbDisplay(_INTL("The melody banished the dark!"))
          multipliers[:base_damage_multiplier] *= 0.5
end
      # Newer Fields [add code Below me]#
      when 13
      when 14
      when 15
      when 16
      when 17
      when 18
      when 19
      when 20
      when 21
      when 22
      when 23
      when 24
      when 25
      # Newer Fields [Add Code above me]#
    end
    fieldEffects_pbCalcDamageMultipliers(user,target,numTargets,type,baseDmg,multipliers)
  end
end
