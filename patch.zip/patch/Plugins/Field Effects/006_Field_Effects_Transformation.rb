#============================================================================
#
#	Field Transformations are all done here.
#	While you don't have to, I decided to seperate damage dealing moves from 
#	status moves, mostly for organisations sake.
#
#	The code is the same all the time
#	case $game_temp.fieldEffectsBg
#		when x
#			if [:MOVEHERE].include?(move.id)
#				$game_temp.fieldEffectsBg = xyz  
#				@battle.scene.pbChangeBGSprite
#				@battle.pbDisplay(_INTL("blahblah!"))
#			end
#		when y
#		
#		when z
#		
#	end
#============================================================================

#		FIELD EFFECTS IN ORDER OF NUMBER
#
#	1|	Example Field

#=================================
# Field Transformations
#=================================

class Battle::Battler
  alias fieldeffect_pbEffectsAfterMove pbEffectsAfterMove

  def pbEffectsAfterMove(user, targets, move, numHits)
    fieldeffect_pbEffectsAfterMove(user, targets, move, numHits)
    # STATUS MOVES
    case $game_temp.fieldEffectsBg
    when 1 # Example Field
    when 2 # Volcanic Field
      if [:SANDSTORM].include?(move.id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The sand snuffed out the flame!"))
      end
      if [:RAINDANCE].include?(move.id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The rain snuffed out the flame!"))
      end    
      if [:WHIRLWIND,:DEFOG,:TAILWIND].include?(move.id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The wind snuffed out the flame!"))
      end    
      if [:WATERSPORT].include?(@id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The water snuffed out the flame!"))
      end
    end
    # DAMAGE DEALING MOVES
    case $game_temp.fieldEffectsBg
    when 1 # Example Field
      if ![:Rain, :HeavyRain].include?(@battle.pbWeather)
        if [:FIREPLEDGE, :FIREBLAST, :FLAMEBURST].include?(move.id)
          $game_temp.fieldEffectsBg = 0 # No Field 
          @battle.scene.pbChangeBGSprite
          @battle.pbDisplay(_INTL("The example field is gone!"))
        end
      end    
    when 2 # Volcanic Field
      if [:SANDTOMB].include?(move.id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The sand snuffed out the flame!"))
      end
      if [:BLIZZARD].include?(move.id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The blizzard snuffed out the flame!"))
      end
      if [:GUST,:RAZORWIND,:HURRICANE].include?(@id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The wind snuffed out the flame!"))
      end
      if  [:SURF,:MUDDYWATER,:WATERPLEDGE,:WATERSPOUT,:SPARKLINGARIA,:HYDROVORTEX,:OCEANICOPERRATA].include?(@id)
        $game_temp.fieldEffectsBg = 3 # Cave Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The water snuffed out the flame!"))
      end
    when 8 # Garden Field
      if [:ERUPTION,:LAVAPLUME,:HEATWAVE,:OVERHEAT,:FUSIONFLARE,:FLAMETHROWER,:FIRESPIN].include?(@id)
        $game_temp.fieldEffectsBg = 2 # Volcanic Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The flame ignited the field!"))
      end
      if [:SURF,:RAINDANCE,:MUDDYWATER,:WATERPLEDGE,:WATERSPOUT,:SPARKLINGARIA,:HYDROVORTEX,:OCEANICOPERRATA].include?(@id)
        $game_temp.fieldEffectsBg = 8 # Garden Field 
        @battle.scene.pbChangeBGSprite
        @battle.pbDisplay(_INTL("The water snuffed out the flame!"))
      end
    end
  end
end

MenuHandlers.add(:battle_debug_menu, :fieldeffects, {
  "name"        => _INTL("Fields..."),
  "parent"      => :main,
  "description" => _INTL("Modify the current field Data")
})

MenuHandlers.add(:battle_debug_menu, :field_chang_1, {
  "name"        => _INTL("Example Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Example Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 1
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("Example text for the example field!"))
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_2, {
  "name"        => _INTL("Volcanic Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Volcanic Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 2
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("The field is molten!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_3, {
  "name"        => _INTL("Cave Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Cave Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 3
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("The cave echoes dully...")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_4, {
  "name"        => _INTL("Forest Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Forest Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 4
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("Trees fill the arena!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_5, {
  "name"        => _INTL("Beach Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Beach Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 5
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("The waves crash against the shore!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_6, {
  "name"        => _INTL("Sky Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Sky Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 6
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("The open air rushes past you!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_7, {
  "name"        => _INTL("City Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the City Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 7
    @battle.scene.
    pbMessage(_INTL("The city streets are vibrant!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_8, {
  "name"        => _INTL("Garden Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Garden Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 8
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("The petals dance in the wind!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_9, {
  "name"        => _INTL("Slums Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Slums Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 9
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("Survival of the fittest...")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_10, {
  "name"        => _INTL("Swarm Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Swarm Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 10
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("There's an infestation!")) # 
  }
})

MenuHandlers.add(:battle_debug_menu, :field_chang_11, {
  "name"        => _INTL("Factory Field"),
  "parent"      => :fieldeffects,
  "description" => _INTL("Change the Field to the Factory Field"),
  "effect"      => proc { |battle|
    $game_temp.fieldEffectsBg = 11
    @battle.scene.pbChangeBGSprite
    pbMessage(_INTL("The gears keep turning...")) # 
  }
})
