#===============================================================================
# Enhanced Field-Smart AI - Version 2
#===============================================================================

module BattleFieldAISmart
  # Configuration - similar to your main AI
  FIELD_PREDICTION_DEPTH = 2        # How many turns to predict field changes
  FIELD_CHANGE_THRESHOLD = 0.6      # When to prioritize field changes (0-1)
  CACHE_FIELD_CALCULATIONS = true   # Cache field effect calculations
  MAX_FIELD_CALC_TIME = 0.05        # Max time for field calculations
  DEBUG_MODE = false                # Enable debug output
  
  # Field type mappings for easier maintenance
  FIELD_EFFECTS = {
    2  => :volcanic,   3  => :cave,      4  => :forest,    5  => :beach,
    6  => :sky,        7  => :city,      8  => :garden,    9  => :slums,
    10 => :swarm,      11 => :factory,   12 => :rave,      13 => :custom_1,
    14 => :custom_2,   15 => :custom_3,  16 => :custom_4,  17 => :custom_5
  }.freeze
  
  #-----------------------------------------------------------------------------
  # Enhanced Field AI Handler with improved architecture
  #-----------------------------------------------------------------------------
  
  class SmartFieldAI
    def initialize(battle_ai)
      @ai = battle_ai
      @battle = battle_ai.battle
      @field_cache = {}
      @move_cache = {}
      @calculation_start_time = nil
      @cache_stats = { hits: 0, misses: 0 }
    end
    
    # Main enhancement method with timeout protection
    def enhance_field_awareness(idxBattler, choices)
      return choices if choices.nil? || choices.empty?
      
      user = @battle.battlers[idxBattler]
      return choices if user.nil? || user.fainted? || user.wild?
      return choices unless field_active?
      
      @calculation_start_time = Time.now
      
      begin
        # Apply field-aware enhancements
        enhanced_choices = choices.map do |choice|
          break choices if calculation_timeout?
          
          move_idx, score, target = choice
          next choice if score <= 0 || move_idx.nil?
          
          move = safe_get_move(user, move_idx)
          next choice if move.nil?
          
          # Apply field-aware scoring
          new_score = field_aware_score_move(user, move, target, score)
          
          [move_idx, new_score, target]
        end
        
        # Add field change considerations
        field_change_bonus = evaluate_field_change_priority(user)
        if field_change_bonus > 0
          enhanced_choices = apply_field_change_bonus(enhanced_choices, field_change_bonus)
        end
        
        # Sort by enhanced score
        enhanced_choices.sort_by.with_index { |(choice, idx)| [-choice[1], idx] }
        
      rescue => e
        puts "Field AI Error: #{e.message}" if DEBUG_MODE
        return choices
      end
    end
    
    # Enhanced field-aware move scoring
    def field_aware_score_move(user, move, target, base_score)
      return 0 if base_score <= 0
      return base_score if calculation_timeout?
      
      score = base_score.to_f
      field_id = get_current_field_id
      
      return score.to_i unless field_id
      
      begin
        # 1. Direct field effect bonus/penalty
        field_multiplier = calculate_field_move_multiplier(move, field_id)
        score *= field_multiplier if field_multiplier != 1.0
        
        # 2. Field synergy bonus
        synergy_bonus = calculate_field_synergy_bonus(user, move, field_id)
        score += synergy_bonus if synergy_bonus > 0
        
        # 3. Field hazard consideration
        hazard_adjustment = calculate_field_hazard_adjustment(user, move, field_id)
        score += hazard_adjustment if hazard_adjustment != 0
        
        # 4. Field transition prediction
        transition_bonus = calculate_field_transition_bonus(user, move, target, field_id)
        score += transition_bonus if transition_bonus != 0
        
        # 5. Strategic field positioning
        positioning_bonus = calculate_field_positioning_bonus(user, move, field_id)
        score += positioning_bonus if positioning_bonus > 0
        
      rescue => e
        puts "Field scoring error: #{e.message}" if DEBUG_MODE
        return base_score
      end
      
      [score.to_i, 1].max
    end
    
    #-----------------------------------------------------------------------------
    # Field Effect Calculation Methods
    #-----------------------------------------------------------------------------
    
    def calculate_field_move_multiplier(move, field_id)
      return 1.0 unless move && field_id
      return 1.0 if calculation_timeout?
      
      cache_key = "multiplier_#{move.id}_#{field_id}"
      
      if CACHE_FIELD_CALCULATIONS && @field_cache[cache_key]
        @cache_stats[:hits] += 1
        return @field_cache[cache_key]
      end
      
      @cache_stats[:misses] += 1
      
      multiplier = case FIELD_EFFECTS[field_id]
                   when :volcanic then volcanic_field_multiplier(move)
                   when :cave     then cave_field_multiplier(move)
                   when :forest   then forest_field_multiplier(move)
                   when :beach    then beach_field_multiplier(move)
                   when :sky      then sky_field_multiplier(move)
                   when :city     then city_field_multiplier(move)
                   when :garden   then garden_field_multiplier(move)
                   when :slums    then slums_field_multiplier(move)
                   when :swarm    then swarm_field_multiplier(move)
                   when :factory  then factory_field_multiplier(move)
                   when :rave     then rave_field_multiplier(move)
                   else 1.0
                   end
      
      @field_cache[cache_key] = multiplier if CACHE_FIELD_CALCULATIONS
      multiplier
    end
    
    def calculate_field_synergy_bonus(user, move, field_id)
      return 0 unless move && user && field_id
      return 0 if calculation_timeout?
      
      bonus = 0
      
      begin
        # Team synergy with field
        if team_synergizes_with_field?(user, field_id)
          bonus += 15
        end
        
        # Move combo synergy on specific fields
        if has_field_combo_potential?(user, move, field_id)
          bonus += 20
        end
        
        # Ability-field synergy
        if ability_synergizes_with_field?(user, field_id)
          bonus += 12
        end
        
        # Item-field synergy
        if item_synergizes_with_field?(user, field_id)
          bonus += 8
        end
        
      rescue => e
        puts "Field synergy error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      bonus
    end
    
    def calculate_field_hazard_adjustment(user, move, field_id)
      return 0 unless user && field_id
      return 0 if calculation_timeout?
      
      adjustment = 0
      
      begin
        # Field-specific hazards
        case FIELD_EFFECTS[field_id]
        when :volcanic
          # Avoid staying on field if low HP (burn damage)
          if user.hp <= (user.totalhp * 0.3) && !has_fire_immunity?(user)
            adjustment -= 10 if move && is_non_switching_move?(move)
            adjustment += 15 if move && is_switching_move?(move)
          end
        when :sky
          # Consider fall damage for grounded moves
          if move && causes_grounding?(move)
            adjustment -= 8
          end
        when :factory
          # Electric terrain effects
          if user.grounded? && move && is_status_move?(move)
            adjustment -= 5 # Status moves fail on grounded Pokémon
          end
        end
        
      rescue => e
        puts "Field hazard error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      adjustment
    end
    
    def calculate_field_transition_bonus(user, move, target, field_id)
      return 0 unless move && field_id
      return 0 if calculation_timeout?
      
      bonus = 0
      
      begin
        # Predict if move will change field
        if causes_field_change?(move, field_id)
          new_field = predict_field_after_move(move, field_id)
          if new_field && field_benefits_team?(user, new_field)
            bonus += 25
          elsif new_field && field_hinders_opponent?(target, new_field)
            bonus += 20
          end
        end
        
        # Weather-field interaction
        if affects_weather?(move) && weather_affects_field?(field_id)
          bonus += 15
        end
        
      rescue => e
        puts "Field transition error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      bonus
    end
    
    def calculate_field_positioning_bonus(user, move, field_id)
      return 0 unless move && user && field_id
      return 0 if calculation_timeout?
      
      bonus = 0
      
      begin
        # Strategic positioning based on field
        case FIELD_EFFECTS[field_id]
        when :sky
          if is_flying_type?(user) || has_levitate?(user)
            bonus += 10 # Natural advantage
          end
        when :beach
          if is_ground_type?(user) || is_water_type?(user)
            bonus += 8
          end
        when :forest
          if is_grass_type?(user) || is_bug_type?(user)
            bonus += 8
          end
        end
        
      rescue => e
        puts "Field positioning error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      bonus
    end
    
    #-----------------------------------------------------------------------------
    # Field-Specific Multiplier Methods
    #-----------------------------------------------------------------------------
    
    def volcanic_field_multiplier(move)
      return 1.5 if move_has_type?(move, :FIRE)
      return 0.5 if move_has_type?(move, :GRASS) || move_has_type?(move, :ICE)
      1.0
    end
    
    def cave_field_multiplier(move)
      return 1.5 if move_has_type?(move, :ROCK) || is_sound_move?(move)
      return 0.5 if move_has_type?(move, :FLYING) && !is_contact_move?(move)
      1.0
    end
    
    def forest_field_multiplier(move)
      return 1.5 if move_has_type?(move, :GRASS) || move_has_type?(move, :BUG)
      return 2.0 if is_cutting_move?(move) || move.id == :ATTACKORDER
      1.0
    end
    
    def beach_field_multiplier(move)
      return 1.5 if move_has_type?(move, :GROUND) || move_has_type?(move, :WATER)
      return 2.0 if is_sand_move?(move) || is_mud_move?(move)
      return 1.3 if is_focus_move?(move)
      1.0
    end
    
    def sky_field_multiplier(move)
      return 1.5 if move_has_type?(move, :FLYING)
      return 2.0 if is_wind_move?(move)
      return 0.2 if move_has_type?(move, :GROUND)
      return 0.5 if move_has_type?(move, :ROCK)
      1.0
    end
    
    def city_field_multiplier(move)
      return 1.5 if move_has_type?(move, :NORMAL) || move_has_type?(move, :FAIRY)
      return 0.5 if move_has_type?(move, :POISON)
      1.0
    end
    
    def garden_field_multiplier(move)
      return 1.5 if move_has_type?(move, :GRASS) || move_has_type?(move, :FIRE)
      return 2.0 if move.id == :SOLARBEAM
      return 0.5 if move_has_type?(move, :WATER)
      1.0
    end
    
    def slums_field_multiplier(move)
      return 1.5 if move_has_type?(move, :DARK) || move_has_type?(move, :POISON)
      return 2.0 if move.id == :BITE
      return 1.5 if move.id == :CRUNCH
      return 0.5 if move_has_type?(move, :GRASS)
      1.0
    end
    
    def swarm_field_multiplier(move)
      return 1.5 if move_has_type?(move, :BUG)
      return 2.0 if is_cutting_move?(move) || move.id == :ATTACKORDER
      return 0.5 if move_has_type?(move, :WATER)
      1.0
    end
    
    def factory_field_multiplier(move)
      return 1.5 if move_has_type?(move, :ELECTRIC) || move_has_type?(move, :STEEL)
      return 0.5 if is_wind_move?(move)
      1.0
    end
    
    def rave_field_multiplier(move)
      return 1.5 if move_has_type?(move, :NORMAL) || is_sound_move?(move)
      return 1.5 if is_showy_move?(move)
      return 0.5 if move_has_type?(move, :DARK)
      1.0
    end
    
    #-----------------------------------------------------------------------------
    # Field Change Evaluation
    #-----------------------------------------------------------------------------
    
    def evaluate_field_change_priority(user)
      return 0 unless field_active?
      return 0 if calculation_timeout?
      
      current_field = get_current_field_id
      ideal_field = calculate_ideal_field_for_team(user)
      
      return 0 if current_field == ideal_field
      
      # Calculate priority based on team benefit
      team_benefit = calculate_team_field_benefit(user, ideal_field)
      opponent_detriment = calculate_opponent_field_detriment(user, ideal_field)
      
      (team_benefit + opponent_detriment) * FIELD_CHANGE_THRESHOLD
    end
    
    def calculate_ideal_field_for_team(user)
      return 2 unless user # Fallback to Volcanic
      
      begin
        # Analyze team composition
        type_weights = calculate_team_type_weights(user)
        
        # Find best field based on type coverage
        best_field = 2
        best_score = 0
        
        FIELD_EFFECTS.each do |field_id, field_type|
          score = calculate_field_team_score(type_weights, field_id)
          if score > best_score
            best_score = score
            best_field = field_id
          end
        end
        
        best_field
      rescue => e
        puts "Ideal field calculation error: #{e.message}" if DEBUG_MODE
        2
      end
    end
    
    #-----------------------------------------------------------------------------
    # Helper Methods - Enhanced with better error handling
    #-----------------------------------------------------------------------------
    
    def safe_get_move(user, move_idx)
      return nil unless user&.moves && move_idx
      return nil unless move_idx >= 0 && move_idx < user.moves.length
      user.moves[move_idx]
    rescue
      nil
    end
    
    def calculation_timeout?
      return false unless @calculation_start_time
      Time.now - @calculation_start_time > MAX_FIELD_CALC_TIME
    end
    
    def field_active?
      return false unless defined?($game_temp)
      return false unless $game_temp.respond_to?(:fieldEffectsBg)
      $game_temp.fieldEffectsBg && $game_temp.fieldEffectsBg > 0
    rescue
      false
    end
    
    def get_current_field_id
      return nil unless field_active?
      $game_temp.fieldEffectsBg
    rescue
      nil
    end
    
    def move_has_type?(move, type)
      return false unless move && move.respond_to?(:type)
      move.type == type
    rescue
      false
    end
    
    # Move property detection methods
    def is_sound_move?(move)
      return false unless move
      move.respond_to?(:soundMove?) && move.soundMove?
    rescue
      false
    end
    
    def is_contact_move?(move)
      return false unless move
      move.respond_to?(:contactMove?) && move.contactMove?
    rescue
      false
    end
    
    def is_cutting_move?(move)
      return false unless move
      cutting_moves = [:CUT, :SLASH, :PSYCHOCUT, :FURYCUTTER, :XSCISSOR, :LEAFBLADE]
      cutting_moves.include?(move.id)
    rescue
      false
    end
    
    def is_sand_move?(move)
      return false unless move
      sand_moves = [:SANDTOMB, :SANDATTACK, :SANDSTORM]
      sand_moves.include?(move.id)
    rescue
      false
    end
    
    def is_mud_move?(move)
      return false unless move
      mud_moves = [:MUDSLAP, :MUDSHOT, :MUDBOMB, :MUDDY_WATER]
      mud_moves.include?(move.id)
    rescue
      false
    end
    
    def is_wind_move?(move)
      return false unless move
      wind_moves = [:HURRICANE, :GUST, :AIRSLASH, :AIRCUTTER, :TWISTER, :TAILWIND]
      wind_moves.include?(move.id)
    rescue
      false
    end
    
    def is_focus_move?(move)
      return false unless move
      focus_moves = [:ZENHEADBUTT, :STOREDPOWER, :AURASPHERE, :FOCUSBLAST]
      focus_moves.include?(move.id)
    rescue
      false
    end
    
    def is_showy_move?(move)
      return false unless move
      showy_moves = [:FOCUSPUNCH, :PSYSHIELDBASH, :PSYCHOCUT, :DAZZLINGGLEAM]
      showy_moves.include?(move.id)
    rescue
      false
    end
    
    # Type checking methods
    def is_flying_type?(pokemon)
      return false unless pokemon
      pokemon.hasType?(:FLYING)
    rescue
      false
    end
    
    def is_ground_type?(pokemon)
      return false unless pokemon
      pokemon.hasType?(:GROUND)
    rescue
      false
    end
    
    def is_water_type?(pokemon)
      return false unless pokemon
      pokemon.hasType?(:WATER)
    rescue
      false
    end
    
    def is_grass_type?(pokemon)
      return false unless pokemon
      pokemon.hasType?(:GRASS)
    rescue
      false
    end
    
    def is_bug_type?(pokemon)
      return false unless pokemon
      pokemon.hasType?(:BUG)
    rescue
      false
    end
    
    # Ability and item checks
    def has_levitate?(pokemon)
      return false unless pokemon
      pokemon.hasAbility?(:LEVITATE)
    rescue
      false
    end
    
    def has_fire_immunity?(pokemon)
      return false unless pokemon
      pokemon.hasAbility?(:FLASHFIRE) || pokemon.hasAbility?(:WATERVEIL) ||
      has_fire_type_immunity?(pokemon)
    rescue
      false
    end
    
    def has_fire_type_immunity?(pokemon)
      return false unless pokemon
      pokemon.hasType?(:FIRE) || pokemon.hasType?(:WATER)
    rescue
      false
    end
    
    # Additional helper methods that are referenced but missing
    def apply_field_change_bonus(choices, bonus)
      choices.map do |choice|
        move_idx, score, target = choice
        [move_idx, score + bonus, target]
      end
    end
    
    def team_synergizes_with_field?(user, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def has_field_combo_potential?(user, move, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def ability_synergizes_with_field?(user, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def item_synergizes_with_field?(user, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def is_non_switching_move?(move)
      # Placeholder implementation - you can expand this based on your game logic
      true
    end
    
    def is_switching_move?(move)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def causes_grounding?(move)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def is_status_move?(move)
      return false unless move
      move.respond_to?(:statusMove?) && move.statusMove?
    rescue
      false
    end
    
    def causes_field_change?(move, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def predict_field_after_move(move, current_field)
      # Placeholder implementation - you can expand this based on your game logic
      current_field
    end
    
    def field_benefits_team?(user, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def field_hinders_opponent?(target, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def affects_weather?(move)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def weather_affects_field?(field_id)
      # Placeholder implementation - you can expand this based on your game logic
      false
    end
    
    def calculate_team_field_benefit(user, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      0
    end
    
    def calculate_opponent_field_detriment(user, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      0
    end
    
    def calculate_team_type_weights(user)
      # Placeholder implementation - you can expand this based on your game logic
      {}
    end
    
    def calculate_field_team_score(type_weights, field_id)
      # Placeholder implementation - you can expand this based on your game logic
      0
    end
    
  end # End of SmartFieldAI class
  
end # End of BattleFieldAISmart module