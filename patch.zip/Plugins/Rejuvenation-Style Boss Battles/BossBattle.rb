# Boss Battles by Pokemon Rejuvenation, Updated by the Repudation Team for Essentials v21.1.
module GameData
  class BossBattles
    attr_accessor :id
    attr_accessor :name
    attr_accessor :entryText
    attr_accessor :immunities
    attr_accessor :shieldCount
    attr_accessor :canrun
    attr_accessor :onBreakEffects
    attr_accessor :onEntryEffects
    attr_accessor :pokemon
    attr_accessor :chargeAttack
    attr_accessor :randomSetChanges

    DATA = {}

    def initialize(data)
      data.each do |key, value|
        case key
          when :name              then @name              = value
          when :entryText         then @entryText         = value
          when :shieldCount       then @shieldCount       = value
          when :immunities        then @immunities        = value
          when :canrun            then @canrun            = value
          when :pokemon           then @pokemon           = value
          when :onBreakEffects    then @onBreakEffects    = value
          when :onEntryEffects    then @onEntryEffects    = value
          when :chargeAttack      then @chargeAttack      = value
          when :randomSetChanges  then @randomSetChanges  = value
        end
      end
	  @id_boss   = data[:id]
    end

    extend ClassMethodsSymbols
    include InstanceMethods

    def self.load; end
    def self.save; end
	def get_boss_id; return @id_boss; end
  end
end

#===============================================================================

GameData::BossBattles.register({ #this is pretty much everything that a boss battle can have so test it out
  :id   => :GODSLAYER,
  :shieldCount => 3, # number of shields
  :immunities => { # any immunities to things
    :moves => [:PARTINGSHOT,:FEINT], #these are the moves that the boss is immune (takes no damage) to
    :fieldEffectDamage => [] # there arent any fields that in base essentials that do field effect damage and i dont want to make one
  },
  :entryText => "Heaven-shaking Godkiller appeared.", # dialogue upon enterring battle
  :pokemon => { # pokemon details (obvs)
    :species => :FLYGON,
    :name => "God-Slayer", # nick-name
    :level => 20,
    :form => 0,
    :item => :LEFTOVERS,
    :moves => [:DARKPULSE, :PSYSHOCK, :MOONLIGHT, :MOONBLAST],
    :ability => :RKSSYSTEM,
    :gender => "F",
    :nature => :MODEST,
    :happiness => 255,
    :ev => [252, 0, 4, 0, 252, 0],
    :iv => [31, 0, 31, 31, 31, 31],
    :baseStats => [95, 95, 95, 95, 95, 95],
    :shiny => true
  },
  :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
    :fieldChange => :Misty,
    :fieldChangeMessage => "God-Slayer laughs at how dumb your face looks. So mean!",
    :delayedaction => {
                :delay => 1,
                :playerSideStatChanges => {
                    :SPEED => -1,
                },
                :message => "The aromatic mist is relaxing...",
                :repeat => true,
                :animation => :FAIRYWIND,
            }
  },
  :onBreakEffects => {  # in order of shield count, with the highest value being the first shield broken and the lowest the last
    1 => {
      :threshold => 0, # if desired, shield can be broken at higher hp% than 0
      :message => "God-Slayer is angered!", # message that plays when shield is broken
      :bossEffect => [:MagicCoat,:WRAP], # effect that applies on the boss when breaking shield. Can use arrays for multiple effects or just one without brackets
      :bossEffectduration => [true, -1], # duration of effect, negative number means it lasts forever
      :bossEffectMessage => "{1} shrouded itself with Magic Coat!", # message that plays for the effect
      :bossEffectanimation => :MAGICCOAT, # effect animation
      :speciesUpdate => :GARCHOMP, # change the pokemon
      :formchange => 1, # formchanges
      :abilitychange => :DOWNLOAD, # ability to change to upon shieldbreaker
      :fieldChange => :Grassy, # field changes
      :weatherChange => :Rain, # weather to apply
      :weatherCount => 5, # weather duration
      :weatherChangeMessage => "Rain began to fall!", # weather message
      :weatherChangeAnimation => "Rain", # weather animation
      :typeChange => [:FIRE, :ROCK], # any given type changes
      :movesetUpdate => [:EARTHQUAKE, :OUTRAGE, :ROCKSLIDE, :FIREBLAST], # moveset changes
      :statusCure => true, # cure status
      :effectClear => true, # clear effects
      :bossSideStatusChanges => :POISON, # status change on boss's side
      :playerSideStatusChanges => :BURN, # status change on player's side
      :statDropCure => true, # cure stat drops
      :playerEffects => [:Curse,:FIRESPIN], # effects that apply on player's side
      :playerEffectsduration => [true, -1], #negative number means it lasts forever
      :playerEffectsAnimation => [:CURSE, :FIRESPIN], # effect animations
      :playerEffectsMessage => "A curse was inflicted on the opposing side!", # effect message
      :stateChanges => :TrickRoom, # state change
      :stateChangeAnimation => :TRICKROOM, # state change animation
      :stateChangeCount => 5, # state change duration
      :stateChangeMessage => "The dimensions were changed!", # state change message
      :playersideChanges => :ToxicSpikes, # player side change
      :playersideChangeAnimation => :TOXICSPIKES, # side change animation
      :playersideChangeCount => 1, # side change duration
      :playersideChangeMessage => "Toxic Spikes was set up on the opposing side!", # side change message
      :bosssideChanges => :ToxicSpikes, # boss side change
      :bosssideChangeAnimation => :TOXICSPIKES, # side change animation
      :bosssideChangeCount => 1, # side change duration
      :bosssideChangeMessage => "Toxic Spikes was set up on the God-Slayer's side!", # side change message
      :itemchange => :LIFEORB, # item change
      :bossStatChanges => { # boss stat changes
        :ATTACK => 1
      },
      :playerSideStatChanges => { # player stat changes
        :ATTACK => -1
      },
      :delayedaction => {
        :delay => 1, # this just means how many turn it will take for the delayed action to happen
        :repeat => true, # repeat forever
        :message => "God-Slayer's type shifted!",
        :typeSequence => { # here the delayed action(changing type) will happen every turn
                    1 => {
                            :typeChange => [:FLYING,:FLYING],
                         },
                    2 => {
                            :typeChange => [:ELECTRIC,:FLYING],
                         },
                    3 => {
                            :typeChange => [:GROUND,:FLYING],
                         },
                    4 => {
                            :typeChange => [:FAIRY,:FLYING],
                         },
                },
      }
    }
  }
})

GameData::BossBattles.register({
  :id => :RAMPANTDRED,
  :shieldCount => 1,
  :immunities => {},
  :pokemon => {
    :species => :DREDNAW,
	:name => "???",
	:level => 100,
    :form => 1,
	:shiny => false,
  },
  :onBreakEffects => {
    1 => {
	  :message => "The unknown Drednaw just lost a shield!"
	},
  },
})
GameData::BossBattles.register({
  :id => :RAMPANTMILO,
  :shieldCount => 1,
  :immunities => {},
  :pokemon => {
    :species => :MILOTIC,
	:name => "R-06",
	:level => 50,
    :form => 2,
	:shiny => false,
  },
  :onBreakEffects => {
    1 => {
	  :message => "The Rampant Milotic just lost a shield!"
	},
  },
})
GameData::BossBattles.register({
  :id => :MAMADOS,
  :shieldCount => 2,
  :immunities => {},
  :pokemon => {
    :species => :ARIADOS,
	:name => "Mamados",
	:level => 41,
    :form => 1,
	:shiny => false,
  },
  :onBreakEffects => {
    1 => {
	  :message => "Mamados just lost a shield!"
	},
  },
})

class Pokemon
  attr_accessor :isbossmon # is a boss pokemon
  attr_accessor :shieldCount # number of shields
  attr_accessor :bossId # id of the boss idk
  attr_accessor :shieldActive
  @isbossmon=false
  def enablebossmon
    @isbossmon=true
  end

  def baseStats
    this_base_stats = species_data.base_stats
    ret = {}
    GameData::Stat.each_main { |s| ret[s.id] = this_base_stats[s.id] }
    if @isbossmon && GameData::BossBattles.try_get(self.bossId).pokemon[:baseStats]
      new_base_stats = GameData::BossBattles.try_get(self.bossId).pokemon[:baseStats]
      statsArr = [:HP, :ATTACK, :DEFENSE, :SPEED, :SPECIAL_ATTACK, :SPECIAL_DEFENSE]
      statsArr.zip(new_base_stats).each { |stat, value| ret[stat] = value } #changes the base stats by assiging the new stats in the pbs format
    end
    return ret
  end
end

class BossBattles
  def self.start(battleId)
    pokemon = pbLoadWildBoss(battleId)
    outcome = WildBattle.start(pokemon)
    # Return false if the player lost or drew the battle, and true if any other result
    return outcome != 2 && outcome != 5
  end

  def self.dual_start(battleId1,battleId2)
    team = pbLoadDualBoss(battleId1,battleId2)
    outcome = WildBattle.start(team[0],team[1])
    # Return false if the player lost or drew the battle, and true if any other result
    return outcome != 2 && outcome != 5
  end

  def self.pbLoadWildBoss(poke) # create a pokemon object that has the boss's pokemon data
    boss = GameData::BossBattles.try_get(poke)
    bossid = poke
    poke = boss.pokemon
    species = poke[:species]
    level = poke[:level]
    form = poke[:form] || 0
    pokemon = Pokemon.new(species, level)
    bossFunction(boss,bossid,pokemon)
    pokemon.item = poke[:item]
    if poke[:moves] && poke[:moves].length > 0
      poke[:moves].each { |move| pokemon.learn_move(move) }
    else
      pokemon.reset_moves
    end
    statsArr = [:HP, :ATTACK, :DEFENSE, :SPEED, :SPECIAL_ATTACK, :SPECIAL_DEFENSE]
    if poke[:iv]
      statsArr.zip(poke[:iv].cycle).each { |stat, value| pokemon.iv[stat] = value } # does the same thing as base stats code
    else
      GameData::Stat.each_main { |s| pokemon.iv[s.id] = 31} # fill in empty iv values
    end
    if poke[:ev]
      statsArr.zip(poke[:ev].cycle).each { |stat, value| pokemon.ev[stat] = value } # does the same thing as base stats code
    else
      GameData::Stat.each_main { |s| pokemon.ev[s.id] = 85} # fill in empty ev values
    end
    pokemon.ability = poke[:ability]
    pokemon.shiny = poke[:shiny] ? poke[:shiny] : false
    pokemon.nature = poke[:nature] ? poke[:nature] : (:HARDY) # Hardy is default nature
    if poke[:form]
      pokemon.forced_form = poke[:form] if MultipleForms.hasFunction?(species, "getForm")
      pokemon.form_simple = poke[:form]
    end
    if !nil_or_empty?(poke[:name])
      pokemon.name = poke[:name]
    end
    pokemon.happiness = poke.fetch(:happiness,70)
    pokemon.poke_ball = poke[:poke_ball] if poke[:poke_ball]
    pokemon.gender = poke[:gender]
    pokemon.calc_stats
    setBattleRule("cannotrun")
    setBattleRule("disablepokeballs")
    return pokemon
  end

  def self.pbLoadDualBoss(poke1,poke2)
    pokemon1 = pbLoadWildBoss(poke1)
    pokemon2 = pbLoadWildBoss(poke2)
    return [pokemon1,pokemon2]
  end
end

def bossFunction(boss, bossid, pokemon) # adds relevant boss stuff to the pokemon
  pokemon.enablebossmon
  pokemon.shieldCount = boss.shieldCount
  pokemon.bossId = bossid
end

class Battle::AI
  def setUpMovesQuick(idxBattler)
    set_up(idxBattler)
    choices = pbGetMoveScores
    pbChooseMove(choices)
  end
end

MenuHandlers.add(:debug_menu, :test_boss_battle, {
  "name"        => _INTL("Test Boss Battle"),
  "parent"      => :battle_menu,
  "description" => _INTL("Start a single battle against a Boss Pokémon."),
  "effect"      => proc {
    $INTERNAL = true
    setBattleRule("canLose")
    boss_data = []
	GameData::BossBattles.each { |data| boss_data.push(data.get_boss_id) }
    command = 0
    cmd = []
	for i in 0...boss_data.length; cmd.push(_INTL(":#{boss_data[i]}")); end
    cmd = pbShowCommands(nil, cmd, -1, command)
	case cmd
	  when -1; next false
	  when cmd; BossBattles.start(boss_data[cmd]); next false
	end
  }
})
