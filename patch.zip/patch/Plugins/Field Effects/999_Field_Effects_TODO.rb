#-------------------------------------
#		EDITED IN THE SCRIPTS
#-------------------------------------

# TERRAINS IN GENERAL
	# Fields now Countdown to 0 and then disappear
	
# VOLCANIC FIELD
	# Burn Up resets at end of turn
	
# CAVE FIELD
	# Ground-Type moves hit Flying-Type Pokémon
	
# Starry Beach
	# Zen Mode edited in the scripts
	
#-----------------------------------
#		TO DO
#-------------------------------------

# VOLCANIC FIELD
	# Melt Ice Face on Switch_In; For now I made it so that Ice Face cant be recovered while on the field
	# Smack Down, Thousand Arrows, Rock Slide, Smog, Clear Smog become DUAL TYPE XYZ/FIRE 
	# Will O Wisp accuracy is 100%

# FOREST FIELD
	# Cut becomes DUAL TYPE XYZ/GRASS
	# Slash, Air Slash, Gale Strike, Fury Cutter, Air Cutter, Psycho Cut, Breaking Swipe become DUAL TYPE XYZ/GRASS

# CAVE FIELD
	# Crystal Cavern Transformation
		# "The cave was littered with crystals!" - Power Gem, Diamond Storm
	# Corrupted Cave Transformation
		# "The cave was corrupted!" - Sludge Wave, Acid Downpour
	# Icy Field Transformation
		# "The cavern froze over!" - Blizzard, Subzero Slammer
	# Dragons Den Transformation
		# "Draconic energy seeps in..." - Dragon Pulse (x2)
		# "The draconic energy mutated the field!" - Draco Meteor, Devastating Drake
	# Cave Collapse 
	
# BEACH 
	# Strength becomes DUAL FIGHTING/PSYCHIC
	# Meditate effects being amplified
	# Sand Tomb lowers Accuracy every end of turn
	# Twister, Fire Spik, Leaf Storm, Razor Wind, Whirlpool lower Accuracy of everyone in the field
	# Special Flying-Type Moves lower accuracy of everyone in the field
