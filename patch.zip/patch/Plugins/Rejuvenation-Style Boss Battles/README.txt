I'm not sure how to add a pbs file to the plugin, so heres the most basic way (and probably the most effiecient way) to make a trainer with a boss pokemon 

As for other stuff the code provided should have enough comments for you to figure stuff out (hopefully)

# How to define a Trainer that has a boss pokemon
#-------------------------------
[CAMPER,IndianAnimator]
LoseText = A very good battle, indeed!
Pokemon = FLYGON,21
    BossId = GODSLAYER