#===============================================================================
# Smart AI Plugin for Pokémon Realities (V2)
#===============================================================================

module BattleAISmart
  # Configuration options - now more granular
  PREDICTION_DEPTH = 5       # How many turns ahead to consider
  RISK_TOLERANCE = 0.7       # 0-1, higher = more risk taking
  SYNERGY_BONUS = 1.2        # Multiplier for moves that synergize
  CACHE_PREDICTIONS = true   # Cache predictions to improve performance
  DEBUG_MODE = false         # Enable debug output
  
  # Performance thresholds
  MAX_CALCULATION_TIME = 0.1 # Maximum seconds per move calculation
  
  #-----------------------------------------------------------------------------
  # Enhanced AI core with improved error handling and performance
  #-----------------------------------------------------------------------------
  
  class SmartAI
    def initialize(battle_ai)
      @ai = battle_ai
      @battle = battle_ai.battle
      @predictions_cache = {}
      @calculation_start_time = nil
    end
    
    # Main enhancement method with timeout protection
    def enhance_move_selection(idxBattler, choices)
      return choices if choices.nil? || choices.empty?
      
      user = @battle.battlers[idxBattler]
      return choices if user.nil? || user.fainted? || user.wild?
      
      @calculation_start_time = Time.now
      
      begin
        # Apply smart enhancements with timeout check
        enhanced_choices = choices.map do |choice|
          break choices if calculation_timeout?
          
          move_idx, score, target = choice
          next choice if score <= 0 || move_idx.nil?
          
          move = safe_get_move(user, move_idx)
          next choice if move.nil?
          
          # Apply smart scoring with safety checks
          new_score = smart_score_move(user, move, target, score)
          
          [move_idx, new_score, target]
        end
        
        # Sort by enhanced score, maintaining original order for ties
        enhanced_choices.sort_by.with_index { |(choice, idx)| [-choice[1], idx] }
        
      rescue => e
        # Fallback to original choices on any error
        puts "Smart AI Error: #{e.message}" if DEBUG_MODE
        return choices
      end
    end
    
    # Enhanced smart scoring with better error handling
    def smart_score_move(user, move, target, base_score)
      return 0 if base_score <= 0
      return base_score if calculation_timeout?
      
      score = base_score.to_f
      
      begin
        # 1. Prediction bonus (with caching)
        prediction_bonus = calculate_prediction_bonus(user, move, target)
        score += prediction_bonus if prediction_bonus > 0
        
        # 2. Enhanced synergy detection
        if has_move_synergy?(user, move)
          score *= SYNERGY_BONUS
        end
        
        # 3. Improved risk assessment
        score = apply_enhanced_risk_assessment(user, move, target, score)
        
        # 4. Context-aware endgame consideration
        endgame_bonus = calculate_endgame_bonus(user, move, target)
        score += endgame_bonus if endgame_bonus > 0
        
        # 5. NEW: Team composition bonus
        team_bonus = calculate_team_composition_bonus(user, move)
        score += team_bonus if team_bonus > 0
        
        # 6. NEW: Turn economy consideration
        turn_bonus = calculate_turn_economy_bonus(user, move, target)
        score += turn_bonus if turn_bonus != 0
        
      rescue => e
        puts "Smart scoring error: #{e.message}" if DEBUG_MODE
        return base_score
      end
      
      [score.to_i, 1].max # Ensure minimum score of 1
    end
    
    #-----------------------------------------------------------------------------
    # Enhanced prediction system with caching
    #-----------------------------------------------------------------------------
    
    def calculate_prediction_bonus(user, move, target)
      return 0 unless target&.opposes?(user)
      return 0 if calculation_timeout?
      
      cache_key = "#{target.index}_#{target.pokemon&.species}_#{@battle.turnCount}"
      
      if CACHE_PREDICTIONS && @predictions_cache[cache_key]
        opponent_moves = @predictions_cache[cache_key]
      else
        opponent_moves = predict_opponent_moves(target, PREDICTION_DEPTH)
        @predictions_cache[cache_key] = opponent_moves if CACHE_PREDICTIONS
      end
      
      bonus = 0
      opponent_moves.each do |opp_move_data|
        opp_move, confidence = opp_move_data
        next unless opp_move && confidence > 0
        
        if counters_move?(user, move, target, opp_move)
          bonus += (20 * confidence).to_i
        end
      end
      
      bonus
    end
    
    # Enhanced move synergy detection
    def has_move_synergy?(user, move)
      return false unless move && user&.moves
      
      begin
        # Check with recently used moves (last 2 turns)
        recent_synergy = check_recent_move_synergy(user, move)
        return true if recent_synergy
        
        # Check with current moveset
        user.moves.any? do |other_move|
          next if other_move.nil? || other_move.id == move.id
          calculate_move_synergy(move, other_move)
        end
      rescue => e
        puts "Synergy check error: #{e.message}" if DEBUG_MODE
        false
      end
    end
    
    # Enhanced risk assessment with more factors
    def apply_enhanced_risk_assessment(user, move, target, score)
      return score unless move && user
      
      risk_multiplier = 1.0
      
      begin
        # Accuracy risk (improved calculation)
        if move.accuracy > 0 && move.accuracy < 100
          accuracy_risk = (100 - move.accuracy) * 0.008 # Reduced impact
          risk_multiplier -= accuracy_risk * (1 - RISK_TOLERANCE)
        end
        
        # Recoil/self-damage risk
        if is_recoil_move?(move)
          recoil_risk = calculate_recoil_risk(user, move)
          risk_multiplier -= recoil_risk * (1 - RISK_TOLERANCE)
        end
        
        # Status condition risk
        if move.respond_to?(:statusMove?) && move.statusMove?
          # Reduce risk for status moves when user is healthy
          if user.hp > (user.totalhp * 0.7)
            risk_multiplier += 0.1 * RISK_TOLERANCE
          end
        end
        
        # Situational risk (low HP, status conditions)
        situational_risk = calculate_situational_risk(user, target)
        risk_multiplier -= situational_risk * (1 - RISK_TOLERANCE)
        
      rescue => e
        puts "Risk assessment error: #{e.message}" if DEBUG_MODE
        return score
      end
      
      (score * [risk_multiplier, 0.1].max).to_i
    end
    
    # Enhanced endgame bonus calculation
    def calculate_endgame_bonus(user, move, target)
      return 0 unless move && user
      return 0 unless is_endgame_situation?(user)
      
      bonus = 0
      
      begin
        health_ratio = user.hp.to_f / user.totalhp
        opponent_count = count_remaining_opponents(user)
        
        if is_winning?(user)
          # Aggressive finishing moves when winning
          if move.damagingMove?
            bonus += (move.base_damage || 0) / 8
            bonus += 15 if is_priority_move?(move)
          end
        else
          # Defensive/setup moves when losing
          if is_status_move?(move)
            bonus += 25
            bonus += 15 if is_healing_move?(move)
          end
          
          # Desperation moves when critically low
          if health_ratio < 0.3 && opponent_count > 1
            bonus += 20 if is_high_risk_high_reward?(move)
          end
        end
        
      rescue => e
        puts "Endgame bonus error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      bonus
    end
    
    # NEW: Team composition consideration
    def calculate_team_composition_bonus(user, move)
      return 0 unless move && user
      
      bonus = 0
      
      begin
        # Role fulfillment bonus
        if is_support_role?(user) && is_support_move?(move)
          bonus += 15
        elsif is_sweeper_role?(user) && move.damagingMove?
          bonus += 10
        end
        
        # Type coverage bonus
        if provides_type_coverage?(user, move)
          bonus += 12
        end
        
      rescue => e
        puts "Team composition error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      bonus
    end
    
    # NEW: Turn economy bonus (rewards efficient moves)
    def calculate_turn_economy_bonus(user, move, target)
      return 0 unless move && user && target
      
      bonus = 0
      
      begin
        # Multi-target moves in doubles
        if @battle.pbSideSize(0) > 1 && targets_multiple?(move)
          bonus += 20
        end
        
        # OHKO potential
        if can_likely_ohko?(user, move, target)
          bonus += 25
        end
        
        # Setup moves early in battle
        if @battle.turnCount < 3 && is_setup_move?(move)
          bonus += 18
        end
        
        # Moves that save turns (like Substitute before status)
        if saves_future_turns?(move, target)
          bonus += 15
        end
        
      rescue => e
        puts "Turn economy error: #{e.message}" if DEBUG_MODE
        return 0
      end
      
      bonus
    end
    
    #-----------------------------------------------------------------------------
    # Enhanced helper methods with better error handling
    #-----------------------------------------------------------------------------
    
    def predict_opponent_moves(target, depth)
      return [] unless target&.moves && depth > 0
      return [] if calculation_timeout?
      
      begin
        predictions = target.moves.compact.map do |move|
          next nil unless move
          
          # Calculate multiple factors for prediction confidence
          effectiveness = calculate_move_effectiveness(move, target, get_likely_switch_in(target.index))
          usage_weight = calculate_usage_weight(move)
          situational_weight = calculate_situational_weight(target, move)
          
          confidence = (effectiveness + usage_weight + situational_weight) / 3.0
          [move, confidence.clamp(0.1, 2.0)]
        end.compact
        
        predictions.sort_by { |_, confidence| -confidence }.take(3)
      rescue => e
        puts "Prediction error: #{e.message}" if DEBUG_MODE
        []
      end
    end
    
    def counters_move?(user, move, target, opp_move)
      return false unless move && opp_move && user && target
      
      begin
        # Priority advantage
        move_priority = get_move_priority(move, user)
        opp_priority = get_move_priority(opp_move, target)
        
        if move_priority > opp_priority && is_damaging_move?(opp_move)
          return true
        end
        
        # Protection moves
        if is_protection_move?(move) && is_damaging_move?(opp_move)
          return true
        end
        
        # Type effectiveness advantage
        if move.damagingMove? && has_type_advantage?(move, user, target)
          return true
        end
        
        # Status counter (e.g., Aromatherapy vs status moves)
        if counters_status?(move, opp_move)
          return true
        end
        
      rescue => e
        puts "Counter check error: #{e.message}" if DEBUG_MODE
        return false
      end
      
      false
    end
    
    # Enhanced move synergy calculation
    def calculate_move_synergy(move1, move2)
      return false unless move1 && move2
      
      begin
        # Weather synergy
        return true if weather_synergy?(move1, move2)
        
        # Terrain synergy
        return true if terrain_synergy?(move1, move2)
        
        # Stat boost synergy (more comprehensive)
        return true if stat_synergy?(move1, move2)
        
        # Ability synergy
        return true if ability_synergy?(move1, move2)
        
        # Combo moves (like Belly Drum + Sitrus Berry effect)
        return true if combo_synergy?(move1, move2)
        
      rescue => e
        puts "Synergy calculation error: #{e.message}" if DEBUG_MODE
        return false
      end
      
      false
    end
    
    #-----------------------------------------------------------------------------
    # Safety and utility methods
    #-----------------------------------------------------------------------------
    
    def safe_get_move(user, move_idx)
      return nil unless user&.moves && move_idx
      return nil unless move_idx >= 0 && move_idx < user.moves.length
      user.moves[move_idx]
    rescue
      nil
    end
    
    def calculation_timeout?
      return false unless @calculation_start_time
      Time.now - @calculation_start_time > MAX_CALCULATION_TIME
    end
    
    def get_likely_switch_in(battler_index)
      # Simple heuristic: return the first non-fainted Pokémon
      # This could be enhanced with more sophisticated prediction
      begin
        side = @battle.sides[battler_index % 2]
        return side.party.find { |p| p && !p.fainted? }
      rescue
        return nil
      end
    end
    
    # Enhanced type effectiveness calculation
    def calculate_move_effectiveness(move, user, target)
      return 1.0 unless move&.damagingMove? && target
      
      begin
        move_type = move.respond_to?(:pbCalcType) ? move.pbCalcType(user) : move.type
        target_types = target.respond_to?(:pbTypes) ? target.pbTypes : [target.type1, target.type2].compact
        
        effectiveness = 1.0
        target_types.each do |target_type|
          type_mod = Effectiveness.calculate(move_type, target_type)
          effectiveness *= type_mod.to_f / Effectiveness::NORMAL_EFFECTIVE
        end
        
        effectiveness
      rescue => e
        puts "Effectiveness calculation error: #{e.message}" if DEBUG_MODE
        1.0
      end
    end
    
    #-----------------------------------------------------------------------------
    # Enhanced detection methods
    #-----------------------------------------------------------------------------
    
    def is_endgame_situation?(user)
      begin
        remaining = @battle.pbAbleNonActiveCount(user.index)
        total_opponents = count_remaining_opponents(user)
        
        remaining <= 1 || total_opponents <= 1 || @battle.turnCount > 20
      rescue
        false
      end
    end
    
    def is_winning?(user)
      begin
        user_side = @battle.sides[user.index % 2]
        opp_side = @battle.sides[(user.index + 1) % 2]
        
        user_hp_ratio = calculate_side_hp_ratio(user_side)
        opp_hp_ratio = calculate_side_hp_ratio(opp_side)
        
        user_hp_ratio > opp_hp_ratio * 1.3
      rescue => e
        puts "Winning calculation error: #{e.message}" if DEBUG_MODE
        false
      end
    end
    
    def calculate_side_hp_ratio(side)
      return 0 unless side&.party
      
      total_hp = 0
      current_hp = 0
      
      side.party.each do |pokemon|
        next unless pokemon
        total_hp += pokemon.totalhp
        current_hp += pokemon.hp
      end
      
      total_hp > 0 ? current_hp.to_f / total_hp : 0
    end
    
    # Additional helper methods for new features
    def is_recoil_move?(move)
      return false unless move
      move.function.to_s.include?("Recoil") rescue false
    end
    
    def is_priority_move?(move)
      return false unless move
      get_move_priority(move, nil) > 0
    end
    
    def get_move_priority(move, user)
      return 0 unless move
      move.respond_to?(:priority) ? move.priority : 0
    rescue
      0
    end
    
    def is_protection_move?(move)
      return false unless move
      ["ProtectUser", "BanefulBunkerUser", "KingsShieldUser"].include?(move.function.to_s) rescue false
    end
    
    def weather_synergy?(move1, move2)
      return false unless move1 && move2
      
      weather_setters = %w[StartSunWeather StartRainWeather StartSandstormWeather StartHailWeather]
      weather_dependent = %w[TwoTurnAttackOneTurnInSun ParalyzeTargetAlwaysHitsInRainHitsTargetInSky]
      
      (weather_setters.include?(move1.function.to_s) && weather_dependent.include?(move2.function.to_s)) ||
      (weather_setters.include?(move2.function.to_s) && weather_dependent.include?(move1.function.to_s))
    rescue
      false
    end
    
    def count_remaining_opponents(user)
      begin
        opp_side = @battle.sides[(user.index + 1) % 2]
        opp_side.party.count { |p| p && !p.fainted? }
      rescue
        1
      end
    end
    
    # Placeholder methods for advanced features (implement as needed)
    def terrain_synergy?(move1, move2); false; end
    def stat_synergy?(move1, move2); false; end
    def ability_synergy?(move1, move2); false; end
    def combo_synergy?(move1, move2); false; end
    def check_recent_move_synergy(user, move); false; end
    def calculate_recoil_risk(user, move); 0.1; end
    def calculate_situational_risk(user, target); 0.0; end
    def is_support_role?(user); false; end
    def is_sweeper_role?(user); true; end
    def is_support_move?(move); move.respond_to?(:statusMove?) && move.statusMove?; end
    def provides_type_coverage?(user, move); false; end
    def targets_multiple?(move); false; end
    def can_likely_ohko?(user, move, target); false; end
    def is_setup_move?(move); false; end
    def saves_future_turns?(move, target); false; end
    def calculate_usage_weight(move); 1.0; end
    def calculate_situational_weight(target, move); 1.0; end
    def has_type_advantage?(move, user, target); false; end
    def counters_status?(move, opp_move); false; end
    def is_damaging_move?(move); move.respond_to?(:damagingMove?) && move.damagingMove?; end
    def is_status_move?(move); move.respond_to?(:statusMove?) && move.statusMove?; end
    def is_healing_move?(move); move.respond_to?(:healingMove?) && move.healingMove?; end
    def is_high_risk_high_reward?(move); false; end
  end
end

#===============================================================================
# Safe injection into base AI system with conflict prevention
#===============================================================================

class Battle::AI
  unless method_defined?(:smart_ai_original_pbChooseMoves)
    alias smart_ai_original_pbChooseMoves pbChooseMoves

    def pbChooseMoves(idxBattler)
      # Get original choices
      choices = smart_ai_original_pbChooseMoves(idxBattler)
      return unless choices

      battler = @battle.battlers[idxBattler]
      return if battler.fainted? || battler.wild?

      begin
        # Apply Core AI enhancements
        enhanced_choices = enhance_move_selection(idxBattler, choices)

        # Apply Field AI if loaded and active
        if defined?(BattleFieldAISmart::SmartFieldAI) && field_active?
          begin
            field_ai = BattleFieldAISmart::SmartFieldAI.new(self)
            enhanced_choices = field_ai.enhance_field_awareness(idxBattler, enhanced_choices)
          rescue => e
            puts "Field AI Error: #{e.message}" if DEBUG_MODE
          end
        end

        # Apply Support Modules if loaded
        if defined?(BattleAIModule)
          begin
            enhanced_choices = BattleAIModule::TeamSynergyModule.adjust_choices(battler, enhanced_choices)
          rescue => e
            puts "TeamSynergyModule error: #{e.message}" if DEBUG_MODE
          end
          begin
            enhanced_choices = BattleAIModule::MoveChainingModule.adjust_choices(battler, enhanced_choices)
          rescue => e
            puts "MoveChainingModule error: #{e.message}" if DEBUG_MODE
          end
          begin
            enhanced_choices = BattleAIModule::TargetingModule.adjust_choices(battler, enhanced_choices)
          rescue => e
            puts "TargetingModule error: #{e.message}" if DEBUG_MODE
          end
          begin
            enhanced_choices = BattleAIModule::DifficultyModule.scale_choices(enhanced_choices)
          rescue => e
            puts "DifficultyModule error: #{e.message}" if DEBUG_MODE
          end
          if defined?(BattleAIModule::IntentAnalyzer)
            begin
              enhanced_choices = BattleAIModule::IntentAnalyzer.adjust_choices(battler, enhanced_choices)
            rescue => e
              puts "IntentAnalyzer error: #{e.message}" if DEBUG_MODE
            end
          end
          if defined?(BattleAIModule::ItemAwarenessModule)
            begin
              enhanced_choices = BattleAIModule::ItemAwarenessModule.adjust_choices(battler, enhanced_choices)
            rescue => e
              puts "ItemAwarenessModule error: #{e.message}" if DEBUG_MODE
            end
            begin
              enhanced_choices = BattleAIModule::ItemAwarenessModule.adjust_self_choices(battler, enhanced_choices)
            rescue => e
              puts "ItemAwarenessModule::Self error: #{e.message}" if DEBUG_MODE
            end
          end
        end

        # Final selection (your original logic)
        totalScore = enhanced_choices.sum { |c| c[1] }
        return if totalScore <= 0

        randNum = pbAIRandom(totalScore)
        enhanced_choices.each do |c|
          randNum -= c[1]
          next if randNum >= 0
          @battle.pbRegisterMove(idxBattler, c[0], false)
          @battle.pbRegisterTarget(idxBattler, c[2]) if c[2] && c[2] >= 0
          break
        end

      rescue => e
        puts "Smart AI Error: #{e.message}" if DEBUG_MODE
        # Fallback to original choices
        smart_ai_original_pbChooseMoves(idxBattler)
      end
    end

    # Helper method for field checks
    def field_active?
      $game_temp.fieldEffectsBg && $game_temp.fieldEffectsBg > 0 rescue false
    end
  end
end