#===============================================================================
# Move Logger Mod for Pokemon Essentials v20.1 (Safe Version)
# Logs all move usage and effects to logs.txt
# 
# Installation: Place this script above Main in the script editor
# Usage: Logs are automatically written to logs.txt in your game folder
#===============================================================================

module MoveLogger
  LOG_FILE = "logs.txt"
  
  # Initialize log file
  def self.initialize_log
    File.open(LOG_FILE, "w") do |f|
      f.puts "=== POKEMON MOVE LOGGER INITIALIZED ==="
      f.puts "Time: #{Time.now}"
      f.puts "====================================="
      f.puts ""
    end
  rescue
    # Fail silently if we can't write to log
  end
  
  # Write to log file
  def self.log(message)
    File.open(LOG_FILE, "a") do |f|
      f.puts "[#{Time.now.strftime("%H:%M:%S")}] #{message}"
    end
  rescue
    # Fail silently if we can't write to log
  end
  
  # Log move usage (simplified)
  def self.log_move_usage(move_name, user_name, function_code = "Unknown")
    log("MOVE USED: #{user_name} used #{move_name}")
    log("  Function Code: #{function_code}")
  end
  
  # Log move effects
  def self.log_move_effect(effect_name, user_name, details = "")
    log("EFFECT: #{effect_name} - #{user_name} #{details}")
  end
end

# Initialize log when game starts (safer approach)
if defined?(Scene_Map)
  class Scene_Map
    alias move_logger_original_main main if method_defined?(:main)
    def main
      MoveLogger.initialize_log
      if respond_to?(:move_logger_original_main)
        move_logger_original_main
      else
        super
      end
    end
  end
end

#===============================================================================
# Hook into SwitchOutUserDamagingMove specifically (this is what we need most)
#===============================================================================
if defined?(Battle::Move::SwitchOutUserDamagingMove)
  class Battle::Move::SwitchOutUserDamagingMove < Battle::Move
    alias move_logger_original_pbEndOfMoveUsageEffect pbEndOfMoveUsageEffect if method_defined?(:pbEndOfMoveUsageEffect)
    
    def pbEndOfMoveUsageEffect(user, targets, numHits, switchedBattlers)
      MoveLogger.log("=== PIVOTING MOVE DETECTED ===")
      MoveLogger.log("Move: #{@name || 'Unknown'}")
      MoveLogger.log("User: #{user.name rescue 'Unknown'}")
      MoveLogger.log("NumHits: #{numHits}")
      MoveLogger.log("SwitchedBattlers before: #{switchedBattlers}")
      
      # Check all conditions step by step
      if user.fainted?
        MoveLogger.log("EARLY RETURN: User is fainted")
        return
      end
      
      if numHits == 0
        MoveLogger.log("EARLY RETURN: No hits landed")
        return
      end
      
      if @battle.pbAllFainted?(user.idxOpposingSide)
        MoveLogger.log("EARLY RETURN: All opponents fainted")
        return
      end
      
      # Check target switching
      targetSwitched = true
      targets.each do |b|
        if !switchedBattlers.include?(b.index)
          targetSwitched = false
          break
        end
      end
      
      if targetSwitched
        MoveLogger.log("EARLY RETURN: Target already switched")
        return
      end
      
      if !@battle.pbCanChooseNonActive?(user.index)
        MoveLogger.log("EARLY RETURN: Cannot choose non-active Pokemon")
        return
      end
      
      MoveLogger.log("All conditions passed - proceeding with switch")
      
      # Call original method if it exists
      if respond_to?(:move_logger_original_pbEndOfMoveUsageEffect)
        result = move_logger_original_pbEndOfMoveUsageEffect(user, targets, numHits, switchedBattlers)
      else
        # Fallback: call super
        result = super
      end
      
      MoveLogger.log("Switch attempt completed")
      MoveLogger.log("SwitchedBattlers after: #{switchedBattlers}")
      MoveLogger.log("=== END PIVOTING MOVE ===")
      MoveLogger.log("")
      
      return result
    end
  end
end

#===============================================================================
# Hook into battle switch methods (safer version)
#===============================================================================
if defined?(Battle)
  class Battle
    if method_defined?(:pbGetReplacementPokemonIndex)
      alias move_logger_original_pbGetReplacementPokemonIndex pbGetReplacementPokemonIndex
      
      def pbGetReplacementPokemonIndex(idxBattler, randomReplacement = false)
        MoveLogger.log("SWITCH: Getting replacement for battler #{idxBattler}")
        MoveLogger.log("  Random replacement: #{randomReplacement}")
        
        result = move_logger_original_pbGetReplacementPokemonIndex(idxBattler, randomReplacement)
        
        MoveLogger.log("  Replacement index: #{result}")
        if result >= 0
          begin
            battler = @battlers[idxBattler]
            owner = pbGetOwner(idxBattler)
            replacement = owner.party[result]
            MoveLogger.log("  Replacement Pokemon: #{replacement.name}")
          rescue
            MoveLogger.log("  Could not get replacement Pokemon name")
          end
        else
          MoveLogger.log("  No replacement available")
        end
        
        return result
      end
    end
    
    if method_defined?(:pbRecallAndReplace)
      alias move_logger_original_pbRecallAndReplace pbRecallAndReplace
      
      def pbRecallAndReplace(idxBattler, idxParty, batonPass = false)
        begin
          old_name = @battlers[idxBattler].name
          owner = pbGetOwner(idxBattler)
          new_name = owner.party[idxParty].name
          
          MoveLogger.log("RECALL AND REPLACE: #{old_name} -> #{new_name}")
        rescue
          MoveLogger.log("RECALL AND REPLACE: [Could not get Pokemon names]")
        end
        
        MoveLogger.log("  Battler index: #{idxBattler}, Party index: #{idxParty}")
        MoveLogger.log("  Baton Pass: #{batonPass}")
        
        result = move_logger_original_pbRecallAndReplace(idxBattler, idxParty, batonPass)
        
        MoveLogger.log("  Recall and replace completed successfully")
        return result
      end
    end
  end
end

# Simple fallback logging for any move usage
if defined?(PokeBattle_Battler)
  class PokeBattle_Battler
    if method_defined?(:pbUseMove)
      alias move_logger_original_pbUseMove_battler pbUseMove
      
      def pbUseMove(choice, specialUsage = false)
        if choice && choice[2] && choice[2].name
          MoveLogger.log_move_usage(choice[2].name, self.name, choice[2].function)
        end
        
        return move_logger_original_pbUseMove_battler(choice, specialUsage)
      end
    end
  end
end

MoveLogger.log("Move Logger Mod loaded successfully (Safe Version)")