#===============================================================================
# AI SUPPORT MODULES
#===============================================================================

module BattleAIModule
  #=============================================================================
  # CONFIGURATION
  #=============================================================================
  module Config
    # Difficulty levels: 1-5 (1=easy, 5=expert)
    DIFFICULTY = 5
    
    # Module toggles
    ENABLE_TEAM_SYNERGY = true
    ENABLE_ADVANCED_TARGETING = true
    ENABLE_MOVE_CHAINING = true
    
    # Safety settings
    SAFE_MODE = true
    DEBUG_MODE = false
  end

  #=============================================================================
  # CORE AI MODULES
  #=============================================================================
  #-----------------------------------------------------------------------------
  # Team Synergy Module - Analyzes team composition and roles
  #-----------------------------------------------------------------------------
  module TeamSynergyModule
    def self.adjust_choices(user, choices)
      return choices unless Config::ENABLE_TEAM_SYNERGY

      team_roles = analyze_team_roles(user)

      choices.each do |choice|
        move = user.moves[choice[0]]
        next unless move

        # Encourage setup moves if team lacks sweepers
        if team_roles[:needs_setup] && move.statusMove?
          choice[1] += 30
        end

        # Encourage coverage moves if team lacks type spread
        if team_roles[:needs_coverage] && move.damagingMove?
          coverage_score = calculate_coverage_score(move, user, team_roles[:team_coverage])
          choice[1] += (coverage_score * 10).to_i
        end
      end

      choices
    end

    # --- Internal Helpers ---

    def self.analyze_team_roles(user)
      party = user.pbTeam
      setup_count = 0
      full_type_coverage = []

      party.each do |pkmn|
        next if !pkmn || pkmn.fainted?

        setup_count += 1 if has_setup_move?(pkmn)
        full_type_coverage.concat(get_offensive_types(pkmn))
      end

      full_type_coverage.uniq!

      {
        needs_setup: setup_count < 2,
        needs_coverage: full_type_coverage.length < 10, # not diverse enough
        team_coverage: full_type_coverage
      }
    end

    def self.has_setup_move?(pkmn)
      pkmn.moves.any? do |m|
        next false if !m || !m.statusMove?
        GameData::Move.get(m.id).function_code.to_s =~ /RaiseUser|RaiseAll|WorkUp|DragonDance|CalmMind|ShellSmash|QuiverDance/
      end
    end

    def self.get_offensive_types(pkmn)
      pkmn.moves.compact.map do |m|
        data = GameData::Move.get(m.id)
        data.damagingMove? ? data.type : nil
      end.compact
    end

    def self.calculate_coverage_score(move, user, team_coverage)
      move_type = move.type
      return 0 if team_coverage.include?(move_type)

      # Favor types the team lacks
      score = 1.0
      if move_type == :GROUND || move_type == :FIGHTING || move_type == :ICE
        score += 0.5 # commonly useful offensive types
      end
      score
    end
  end

  #-----------------------------------------------------------------------------
  # Advanced Targeting Module - Optimizes target selection
  #-----------------------------------------------------------------------------
  module AdvancedTargetingModule
    def self.adjust_choices(user, choices)
      return choices unless Config::ENABLE_ADVANCED_TARGETING
      
      choices.each do |choice|
        move = user.moves[choice[0]]
        
        # Only apply to single-target moves
        if move.pbTarget(user).num_targets == 1
          best_target = find_optimal_target(user, move)
          choice[2] = best_target.index if best_target
        end
      end
      
      choices
    end
    
    private
    
    def self.find_optimal_target(user, move)
      # Find the best target for this move
      # ... (placeholder for full implementation)
      nil
    end
  end

  #-----------------------------------------------------------------------------
  # Move Chaining Module - Recognizes and rewards move combinations
  #-----------------------------------------------------------------------------
  module MoveChainingModule
    def self.adjust_choices(user, choices)
      return choices unless Config::ENABLE_MOVE_CHAINING
      return choices unless user.lastMoveUsed

      last_move_id = user.lastMoveUsed
      last_move_data = GameData::Move.try_get(last_move_id)
      return choices unless last_move_data

      choices.each do |choice|
        move_index = choice[0]
        move = user.moves[move_index]
        next unless move

        # Static combos
        static_combos = {
          [:THUNDERWAVE, :HEX]          => 20,
          [:WILLOWISP, :HEX]            => 20,
          [:TOXIC, :VENOSHOCK]          => 20,
          [:CALMMIND, :STOREDPOWER]     => 25,
          [:FAKEOUT, :UTURN]            => 10,
          [:FAKEOUT, :PARTINGSHOT]      => 10,
          [:POWERUPPUNCH, :CLOSECOMBAT] => 15
        }
        bonus = static_combos[[last_move_data.id, move.id]] || 0
        choice[1] += bonus if bonus > 0

        # Dynamic: Acrobatics with no item or Flying Gem
        if move.id == :ACROBATICS
          choice[1] += 20 if user.item.nil? || (user.effects && user.effects[:ConsumedItem] == :FLYINGGEM)
        end

        # Dynamic: Stored Power after stat boosts
        if move.id == :STOREDPOWER
          total_boosts = user.stages.values.sum
          choice[1] += total_boosts * 2 if total_boosts > 0
        end

        # Dynamic: Sound move into Throat Spray
        if last_move_data.soundMove? && user.item.nil? && user.effects && user.effects[:ConsumedItem] == :THROATSPRAY
          choice[1] += 15
        end

        # Dynamic: Power Herb charge move followed by synergy
        power_herb_used = user.item.nil? && user.effects && user.effects[:ConsumedItem] == :POWERHERB
        charge_moves = [:SOLARBEAM, :SKYATTACK, :GEOMANCY]
        follow_ups = [:FLAMETHROWER, :MOONBLAST, :AEROBLAST]
        if power_herb_used && charge_moves.include?(last_move_data.id) && follow_ups.include?(move.id)
          choice[1] += 20
        end

        # Dynamic: White Herb follow-up to debuffing move
        if user.item.nil? && user.effects && user.effects[:ConsumedItem] == :WHITEHERB
          if [:SHELLSMASH, :CLOSECOMBAT].include?(last_move_data.id)
            choice[1] += 10
          end
        end
      end

      choices
    end
  end

  #-----------------------------------------------------------------------------
  # Difficulty Scaling Module - Adjusts AI intelligence by difficulty
  #-----------------------------------------------------------------------------
  module DifficultyModule
    DIFFICULTY_MULTIPLIERS = {
      1 => 0.8,  # Easy
      2 => 0.9,  # Normal
      3 => 1.0,  # Hard
      4 => 1.2,  # Expert
      5 => 1.5   # Master
    }.freeze
    
    def self.scale_choices(choices, difficulty = Config::DIFFICULTY)
      multiplier = DIFFICULTY_MULTIPLIERS[difficulty] || 1.0
      
      choices.each do |choice|
        choice[1] = (choice[1] * multiplier).to_i
      end
      
      choices
    end
  end

  #=============================================================================
  # BEHAVIORAL ANALYSIS MODULES
  #=============================================================================

  #-----------------------------------------------------------------------------
  # Intent Analyzer - Predicts and counters opponent strategies
  #-----------------------------------------------------------------------------
  module IntentAnalyzer
    # Move categorization for pattern recognition
    STALL_MOVES = [
      :protect, :detect, :recover, :roost, :wish,
      :substitute, :leechseed, :toxic, :rest, :softboiled
    ].freeze

    SETUP_MOVES = [
      :swordsdance, :calmmind, :bulkup, :nastyplot,
      :agility, :dragondance, :curse, :quiverdance,
      :irondefense, :amnesia
    ].freeze

    HAZARD_MOVES = [
      :stealthrock, :spikes, :toxicspikes, :stickyweb
    ].freeze

    PIVOT_MOVES = [
      :uturn, :voltswitch, :flipturn, :partingshot, :chillyreception
    ].freeze

    def self.adjust_choices(battler, choices)
      opponent = battler.battle.opposingBattler(battler.index)
      return choices unless opponent&.lastMoveUsed

      intent = predict_opponent_intent(opponent)
      apply_counter_strategy(choices, intent)
      
      choices
    end

    private

    def self.predict_opponent_intent(opponent)
      move_id = opponent.lastMoveUsed&.id
      return :aggressive unless move_id

      return :stall if STALL_MOVES.include?(move_id)
      return :setup_boost if SETUP_MOVES.include?(move_id)
      return :hazard_setter if HAZARD_MOVES.include?(move_id)
      return :pivot if PIVOT_MOVES.include?(move_id)
      
      :aggressive
    end

    def self.apply_counter_strategy(choices, intent)
      case intent
      when :setup_boost
        choices.each do |choice|
          move = choice[0]

          # Aggressive pressure
          choice[1] *= 1.25 if move.damagingMove?

          # Deny setup
          choice[1] *= 1.25 if move.function == "Taunt"

          # Stat reset or theft
          if [:HAZE, :CLEARSMOG, :SPECTRALTHIEF].include?(move.id)
            choice[1] *= 1.35
          end

          # Phazing
          if [:ROAR, :WHIRLWIND, :DRAGONTAIL, :CIRCLETHROW].include?(move.id)
            choice[1] *= 1.3
          end

          # Trapping setup sweepers
          if [:MEANLOOK, :BLOCK, :SPIRITSHACKLE].include?(move.id)
            choice[1] *= 1.15
          end

          # Poison setup mons to put them on a timer
          if move.function == "Toxic" || move.statusMove?
            choice[1] *= 1.1 if move.status == :POISON || move.status == :TOXIC
          end
        end

      when :stall
        choices.each do |choice|
          move = choice[0]

          # Break stall with offensive pressure
          choice[1] *= 1.25 if move.damagingMove?

          # Prefer setup breakers
          if [:BULKUP, :SWORDSDANCE, :NASTYPLOT, :CALMMIND].include?(move.id)
            choice[1] *= 1.15
          end

          # Avoid passive moves
          if [:TOXIC, :WISH, :PROTECT, :RECOVER, :SOFTBOILED].include?(move.id)
            choice[1] *= 0.8
          end

          # Strong neutral or SE coverage
          if move.damagingMove? && move.baseDamage >= 90
            choice[1] *= 1.1
          end
        end

      when :pivot
        choices.each do |choice|
          move = choice[0]

          # Devalue passive/slow plays
          choice[1] *= 0.85 if ["Protect", "SetupMove"].include?(move.function)

          # Encourage fast offensive pressure
          choice[1] *= 1.1 if move.damagingMove? && move.priority > 0

          # Catch pivots with trapping or hazards
          if [:MEANLOOK, :BLOCK, :PURSUIT].include?(move.id)
            choice[1] *= 1.2
          end
        end

      when :hazard_setter
        choices.each do |choice|
          move = choice[0]

          # Deny hazard setup
          choice[1] *= 1.25 if move.function == "Taunt"

          # Remove hazards if present
          if [:RAPIDSPIN, :DEFOG].include?(move.id)
            choice[1] *= 1.3
          end

          # Pressure setter with hard hit
          choice[1] *= 1.1 if move.damagingMove?
        end
      end
    end
  end

  #=============================================================================
  # ITEM AWARENESS SYSTEM
  #=============================================================================

  #-----------------------------------------------------------------------------
  # Opponent Item Awareness - Adapts to enemy held items
  #-----------------------------------------------------------------------------
  module ItemAwarenessModule
    def self.adjust_choices(battler, choices)
      opponent = battler.battle.opposingBattler(battler.index)
      return choices unless opponent&.item

      item = opponent.item
      opponent_hp_ratio = opponent.hp.to_f / opponent.totalhp

      choices.each do |choice|
        move = choice[0]
        next unless move&.move
        
        adjust_for_defensive_items(choice, move.move, item, opponent_hp_ratio)
        adjust_for_offensive_items(choice, move.move, item, battler)
        adjust_for_utility_items(choice, move.move, item)
      end

      choices
    rescue => e
      puts "ItemAwarenessModule error: #{e.message}" if Config::DEBUG_MODE
      choices
    end

    private

    def self.adjust_for_defensive_items(choice, move_data, item, hp_ratio)
      case item
      when :AIRBALLOON
        # Don't use Ground moves against Air Balloon
        choice[1] *= 0.4 if move_data.type == :GROUND
        
      when :FOCUSSASH
        # Avoid single hits if opponent at full HP unless multi-hit available
        if hp_ratio == 1.0 && move_data.damagingMove?
          choice[1] *= 0.8 # unless has_multi_hit_followup?
        end
        
      when :ROCKYHELMET
        # Reduce contact move usage
        choice[1] *= 0.85 if move_data.contactMove?
        
      when :EJECTBUTTON, :REDCARD
        # Be cautious with strong attacks if we have momentum
        choice[1] *= 0.9 if move_data.damagingMove?
      end
    end

    def self.adjust_for_offensive_items(choice, move_data, item, battler)
      case item
      when :LIFEORB
        # Favor chip damage and trades
        choice[1] *= 1.05 if move_data.damagingMove?
        
      when :CHOICESCARF, :CHOICEBAND, :CHOICESPECS
        # Avoid setup moves against choice users
        if move_data.function == "SetupMove" || move_data.statusMove?
          choice[1] *= 0.9
        end
        
      when :WEAKNESSPOLICY
        # Avoid super effective moves unless KO is guaranteed
        if move_data.damagingMove?
          # Placeholder for damage calculation
          choice[1] *= 0.7 # if !can_ko_with_move?
        end
      end
    end

    def self.adjust_for_utility_items(choice, move_data, item)
      case item
      when :LUMBERRY
        # Reduce status move effectiveness
        choice[1] *= 0.7 if move_data.function&.include?("Status")
        
      when :SAFETYGOGGLES
        # Reduce powder/spore move effectiveness
        choice[1] *= 0.75 if move_data.flags&.include?(:POWDER)
        
      when :LEFTOVERS, :BLACKSLUDGE
        # Increase offensive pressure against recovery items
        choice[1] *= 1.1 if move_data.damagingMove?
      end
    end
  end

  #-----------------------------------------------------------------------------
  # Self Item Optimization - Maximizes own held item effectiveness
  #-----------------------------------------------------------------------------
  module SelfItemModule
    def self.adjust_choices(battler, choices)
      item = battler.item
      return choices unless item

      hp_ratio = battler.hp.to_f / battler.totalhp

      choices.each do |choice|
        move = choice[0]
        next unless move&.move
        
        optimize_for_item(choice, move.move, item, hp_ratio)
      end

      choices
    rescue => e
      puts "SelfItemModule error: #{e.message}" if Config::DEBUG_MODE
      choices
    end

    private

    def self.optimize_for_item(choice, move_data, item, hp_ratio)
      case item
      when :CHOICESPECS, :CHOICEBAND, :CHOICESCARF
        # Strongly favor attacking moves, avoid status moves
        if move_data.statusMove?
          choice[1] *= 0.6
        elsif move_data.damagingMove?
          choice[1] *= 1.15
        end
        
      when :LIFEORB
        # Boost all damaging moves
        choice[1] *= 1.1 if move_data.damagingMove?
        
      when :FOCUSSASH
        # At full HP, favor setup and priority moves
        if hp_ratio == 1.0
          if move_data.function =~ /Setup|Spikes|ToxicSpikes|StealthRock|StickyWeb/ ||
             move_data.priority > 0
            choice[1] *= 1.2
          end
        end
        
      when :POWERHERB
        # Strongly favor charge-up moves
        if move_data.chargingTurnMove? || move_data.function_code == 0xCE # Geomancy
          choice[1] *= 1.3
        end
        
      when :THROATSPRAY
        # Favor sound-based special moves
        if move_data.soundMove? && move_data.specialMove?
          choice[1] *= 1.2
        end
        
      when :WHITEHERB
        # Synergize with stat-lowering moves
        if move_data.function == "ShellSmash"
          choice[1] *= 1.3
        elsif move_data.statDownSideEffects?
          choice[1] *= 1.2
        end
        
      when :LUMBERRY
        # Use setup/status moves more freely
        if move_data.function =~ /Setup/ || move_data.statusMove?
          choice[1] *= 1.15
        end
        
      when :ASSAULTVEST
        # Cannot use status moves
        choice[1] *= 0.1 if move_data.statusMove?
        
      when :SITRUSBERRY, :AGUAVBERRY, :ORANBERRY
        # At low HP, favor aggressive plays
        if hp_ratio <= 0.5
          choice[1] *= 1.15 if move_data.function =~ /Setup/ || move_data.damagingMove?
        end
        
      when :WEAKNESSPOLICY
        # Favor setup moves to capitalize on potential activation
        choice[1] *= 1.2 if move_data.function =~ /Setup/
        
      when :ROCKYHELMET
        # Slight preference for passive play to bait contact
        choice[1] *= 1.05 if !move_data.contactMove? && move_data.priority <= 0
        
      when :REDCARD, :EJECTBUTTON
        # At low HP, favor damaging moves
        if hp_ratio <= 0.33
          choice[1] *= 1.15 if move_data.damagingMove?
        end
      end
    end
  end
end