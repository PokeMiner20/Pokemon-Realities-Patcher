#===============================================================================
# Data box for boss battles (by Stochastic)
# - adapted by Sardines for Pokemon Rejuvenation
# - Updated by the Repudiation Team for Essentials v21.1.
# - We won't be providing graphics for this plugin, but this code is basically a framework for you to make your own scene.
#===============================================================================
#===============================================================================
# Data box for regular battles
#===============================================================================
class Battle::Scene::BossPokemonDataBox < Sprite
  attr_reader   :battler
  attr_accessor :selected
  attr_reader   :animatingHP
  attr_reader   :animatingExp
  attr_accessor :shieldCount
  attr_reader :shieldX
  attr_reader :shieldY
  attr_reader :shieldGaugeX
  attr_reader :shieldGaugeY

  # Time in seconds to fully fill the Exp bar (from empty).
  EXP_BAR_FILL_TIME  = 1.75
  # Maximum time in seconds to make a change to the HP bar.
  HP_BAR_CHANGE_TIME = 1.0
  STATUS_ICON_HEIGHT = 16
  NAME_BASE_COLOR         = Color.new(255, 255, 255) # Changed by Jos 2022-10-02
  NAME_SHADOW_COLOR       = Color.new(100, 100, 100) # Changed by Jos 2022-10-02
  MALE_BASE_COLOR         = Color.new(255, 255, 255) # Changed by Jos 2022-10-02
  MALE_SHADOW_COLOR       = NAME_SHADOW_COLOR
  FEMALE_BASE_COLOR       = Color.new(255, 255, 255) # Changed by Jos 2022-10-02
  FEMALE_SHADOW_COLOR     = NAME_SHADOW_COLOR

  def initialize(battler, sideSize, viewport = nil)
    super(viewport)
    @battler      = battler
    @sprites      = {}
    @spriteX      = 0
    @spriteY      = 0
    @spriteBaseX  = 0
    @selected     = 0
    @frame        = 0
    @showHP       = false   # Specifically, show the HP numbers
    @animatingHP  = false
    @showExp      = false   # Specifically, show the Exp bar
    @animatingExp = false
    @expFlash     = 0
    @shieldCount  = battler.shieldCount
    @sideSize     = sideSize # Changed by DemICE 17-Oct-2023
    initializeDataBoxGraphic(sideSize)
    initializeOtherGraphics(viewport)
    refresh
  end

  def initializeDataBoxGraphic(sideSize)
    onPlayerSide = @battler.index.even?
    # Get the data box graphic and set whether the HP numbers/Exp bar are shown
    @databoxBitmap&.dispose
    @databoxBitmap = AnimatedBitmap.new("Graphics/Pictures/Battle/boss_bar")
    # Determine the co-ordinates of the data box and the left edge padding width
    if onPlayerSide
      @spriteX = Graphics.width - 244
      @spriteY = Graphics.height - 192
      @spriteBaseX = 34
    else
      @spriteX = -6
      @spriteY = 16
      @spriteBaseX = 16
    end
    case sideSize
      when 2
        @spriteX += [  0,   0,  0,  0][@battler.index]
        @spriteY += [  0, -14,  0, 60][@battler.index]
      when 3
        @spriteX += [  0,   0,  0,  0,  0,  0][@battler.index]
        @spriteY += [  0, -14,  0, 46,  0,106][@battler.index]
    end  
  end

  def initializeOtherGraphics(viewport)
    # Create other bitmaps
    @statBoostsToggle = false
    @numbersBitmap = AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/icon_numbers"))
    @hpBarBitmap   = AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/hpbarboss"))
    @expBarBitmap  = AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/overlay_exp"))
    # Trapstarr's Type Display  # Changed by DemICE 16-Oct-2023 Trapstarr gave me his type icon display script.
    @shieldDisplayBitmap = AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/bossbarshield"))
    # Create sprite to draw HP numbers on
    @hpNumbers = BitmapSprite.new(124, 16, viewport)
    @sprites["hpNumbers"] = @hpNumbers
    # Create sprite wrapper that displays HP bar
    @hpBar = SpriteWrapper.new(viewport)
    @hpBar.bitmap = @hpBarBitmap.bitmap
    @hpBar.src_rect.height = @hpBarBitmap.height / 3
    @sprites["hpBar"] = @hpBar
    # Create sprite wrapper that displays Exp bar
    @expBar = SpriteWrapper.new(viewport)
    @expBar.bitmap = @expBarBitmap.bitmap
    @sprites["expBar"] = @expBar
    # Changed by DemICE 16-Oct-2023 Trapstarr gave me his type icon display script.
    # Trapstarr's Type Display: Create a sprite wrapper that displays Opponents Type
    # Shield Update
    shieldDisplayBitmap = Bitmap.new(Graphics.width, Graphics.height)  
    @shieldDisplay = SpriteWrapper.new(viewport)
    @shieldDisplay.bitmap = shieldDisplayBitmap
    @sprites["shieldDisplay"] = @shieldDisplay
    @sprites["shieldDisplay"].z = 198
    # Create sprite wrapper that displays everything except the above
    @contents = BitmapWrapper.new(@databoxBitmap.width, @databoxBitmap.height)
    self.bitmap  = @contents
    self.visible = false
    self.z       = 150 + ((@battler.index / 2) * 5)
    pbSetSystemFont(self.bitmap)
  end

  def dispose
    pbDisposeSpriteHash(@sprites)
    @databoxBitmap.dispose
    @numbersBitmap.dispose
    @hpBarBitmap.dispose
    @expBarBitmap.dispose
    @shieldbitmaps.dispose if @shieldbitmaps
    # Trapstarr's Type Display Icon # Changed by DemICE 16-Oct-2023 Trapstarr gave me his type icon display script.
    @contents.dispose
    super
  end

  def x=(value)
    super
    @hpBar.x     = value + @spriteBaseX -10
    @expBar.x    = value + @spriteBaseX + 6
    @hpNumbers.x = value + @spriteBaseX + 80
  end

  def y=(value)
    super
    @hpBar.y     = value + 46
    @expBar.y    = value + 74
    @hpNumbers.y = value + 52
  end

  def z=(value)
    super
    @hpBar.z     = value + 1
    @expBar.z    = value + 1
    @hpNumbers.z = value + 2
  end

  def opacity=(value)
    super
    @sprites.each do |i|
      i[1].opacity = value if !i[1].disposed?
    end
  end

  def visible=(value)
    super
    @sprites.each do |i|
      i[1].visible = value if !i[1].disposed?
    end
    @expBar.visible = (value && @showExp)
  end

  def color=(value)
    super
    @sprites.each do |i|
      i[1].color = value if !i[1].disposed?
    end
  end

  def battler=(b)
    @battler = b
    self.visible = (@battler && !@battler.fainted?)
  end

  def hp
    return (@animatingHP) ? @currentHP : @battler.hp
  end

  def exp_fraction
    return 0.0 if @rangeExp == 0
    return (@animatingExp) ? @currentExp.to_f / @rangeExp : @battler.pokemon.exp_fraction
  end

  def animateHP(oldHP, newHP, rangeHP)
    @currentHP   = oldHP
    @endHP       = newHP
    @rangeHP     = rangeHP
    # NOTE: A change in HP takes the same amount of time to animate, no matter
    #       how big a change it is.
    @hpIncPerFrame = (newHP - oldHP).abs / (HP_BAR_CHANGE_TIME * Graphics.frame_rate)
    # minInc is the smallest amount that HP is allowed to change per frame.
    # This avoids a tiny change in HP still taking HP_BAR_CHANGE_TIME seconds.
    minInc = (rangeHP * 4) / (@hpBarBitmap.width * HP_BAR_CHANGE_TIME * Graphics.frame_rate)
    @hpIncPerFrame = minInc if @hpIncPerFrame < minInc
    @animatingHP   = true
  end
  
  def drawShieldDisplay(shields = @shieldCount)
    shieldDisplay = @sprites["shieldDisplay"].bitmap
    shield_width, shield_height = @shieldDisplayBitmap.width, @shieldDisplayBitmap.height
    offset = [@spriteX + 270 - 28,@spriteY + 14]
    shieldX = [  0, 28, 14]
    shieldY = [  0,  0,-14]
    shield_rect = Rect.new(0,0,shield_width,shield_height)
    for i in 0...shields
      shieldDisplay.stretch_blt(Rect.new(offset[0]+shieldX[i],offset[1]+shieldY[i],shield_width,shield_height),@shieldDisplayBitmap.bitmap,shield_rect)
    end
    if shields == 0
      @hpBarBitmap.dispose
      @hpBarBitmap = AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/hpbarboss"))
    end
  end
  
  def animateExp(oldExp, newExp, rangeExp)
    return if rangeExp == 0
    @currentExp     = oldExp
    @endExp         = newExp
    @rangeExp       = rangeExp
    # NOTE: Filling the Exp bar from empty to full takes EXP_BAR_FILL_TIME
    #       seconds no matter what. Filling half of it takes half as long, etc.
    @expIncPerFrame = rangeExp / (EXP_BAR_FILL_TIME * Graphics.frame_rate)
    @animatingExp   = true
    pbSEPlay("Pkmn exp gain") if @showExp
  end

  def pbDrawNumber(number, btmp, startX, startY, align = 0)
    # -1 means draw the / character
    n = (number == -1) ? [10] : number.to_i.digits.reverse
    charWidth  = @numbersBitmap.width / 11
    charHeight = @numbersBitmap.height
    startX -= charWidth * n.length if align == 1
    n.each do |i|
      btmp.blt(startX, startY, @numbersBitmap.bitmap, Rect.new(i * charWidth, 0, charWidth, charHeight))
      startX += charWidth
    end
  end

  def pbBitmap(name)
    begin
      dir = name.split("/")[0...-1].join("/") + "/"
      file = name.split("/")[-1]
      bmp = RPG::Cache.load_bitmap(dir, file)
      bmp.storedPath = name
    rescue
      Console.echo _INTL("Image located at '#{name}' was not found!")
      bmp = Bitmap.new(2,2)
    end
    return bmp
  end

  def pbToggleStatBoosts
    update
  end

  def refresh
    self.bitmap.clear
    return if !@battler.pokemon
    textPos = []
    imagePos = []
    stat_boost = []
    # Shield Updte
    updateshieldDisplay
    # Draw background panel
    self.bitmap.blt(0, 0, @databoxBitmap.bitmap, Rect.new(0, 0, @databoxBitmap.width, @databoxBitmap.height))
    # Draw Pokémon's name
    case @battler.displayGender
      when 0; gender = "♂" # Male
      when 1; gender = "♀" # Female
	  else; gender = ""
    end
	fullname = "#{@battler.name} #{gender}"
    textPos.push([fullname, @spriteBaseX - 6 , 20, false, NAME_BASE_COLOR, NAME_SHADOW_COLOR])
    # Draw Pokémon's gender symbol
    pbDrawTextPositions(self.bitmap, textPos)
    # Draw Pokémon's level
    #imagePos.push(["Graphics/Pictures/Battle/overlay_lv", @spriteBaseX + 178, 26])
    #pbDrawNumber(@battler.level, self.bitmap, @spriteBaseX + 200, 26)
    # Draw shiny icon
    if @battler.shiny?
      imagePos.push(["Graphics/Pictures/shiny", @spriteBaseX + 214, 30])
    end
    # Draw status icon
    if @battler.status != :NONE
      if @battler.status == :POISON && @battler.statusCount > 0   # Badly poisoned
        s = GameData::Status.count - 1
      else
        s = GameData::Status.get(@battler.status).icon_position
      end
      if s >= 0
        imagePos.push(["Graphics/Pictures/Battle/icon_statuses", @spriteBaseX + 214, 56,
                       0, s * STATUS_ICON_HEIGHT, -1, STATUS_ICON_HEIGHT])
      end
    end

    pbDrawImagePositions(self.bitmap, [["Graphics/Pictures/Battle/icon_mega", @spriteBaseX + 143,12]]) if @battler.mega?
    pbDrawImagePositions(self.bitmap, imagePos)
    refreshHP
    refreshExp
  end

  def refreshHP
    @hpNumbers.bitmap.clear
    return if !@battler.pokemon
    # Show HP numbers
    if @showHP
      pbDrawNumber(self.hp, @hpNumbers.bitmap, 54, 2, 1)
      pbDrawNumber(-1, @hpNumbers.bitmap, 54, 2)   # / char
      pbDrawNumber(@battler.totalhp, @hpNumbers.bitmap, 70, 2)
    end
    # Resize HP bar
    w = 0
    if self.hp > 0
      w = @hpBarBitmap.width.to_f * self.hp / @battler.totalhp
      w = 1 if w < 1
      # NOTE: The line below snaps the bar's width to the nearest 2 pixels, to
      #       fit in with the rest of the graphics which are doubled in size.
      w = ((w / 2.0).round) * 2
    end
    @hpBar.src_rect.width = w
    hpColor = 0                                  # Green bar
    hpColor = 1 if self.hp <= @battler.totalhp / 2   # Yellow bar
    hpColor = 2 if self.hp <= @battler.totalhp / 4   # Red bar
    @hpBar.src_rect.y = hpColor * @hpBarBitmap.height / 3
  end

  def refreshExp
    return if !@showExp
    w = exp_fraction * @expBarBitmap.width
    # NOTE: The line below snaps the bar's width to the nearest 2 pixels, to
    #       fit in with the rest of the graphics which are doubled in size.
    w = ((w / 2).round) * 2
    @expBar.src_rect.width = w
  end

  def refreshShieldDisplay(shields = @shieldCount)
    @shieldDisplay.bitmap.clear
    return if !@battler.pokemon || @battler.fainted?
    if shields > 0
      drawShieldDisplay(shields)
    end
  end

  def updateshieldDisplay(shield = @battler.shieldCount)
    @shieldCount = @battler.shieldCount
    refreshShieldDisplay(@shieldCount)
  end

  def updateHPAnimation
    return if !@animatingHP
    if @currentHP < @endHP      # Gaining HP
      @currentHP += @hpIncPerFrame
      @currentHP = @endHP if @currentHP >= @endHP
    elsif @currentHP > @endHP   # Losing HP
      @currentHP -= @hpIncPerFrame
      @currentHP = @endHP if @currentHP <= @endHP
    end
    # Refresh the HP bar/numbers
    refreshHP
    @animatingHP = false if @currentHP == @endHP
  end

  def updateExpAnimation
    return if !@animatingExp
    if !@showExp   # Not showing the Exp bar, no need to waste time animating it
      @currentExp = @endExp
      @animatingExp = false
      return
    end
    if @currentExp < @endExp   # Gaining Exp
      @currentExp += @expIncPerFrame
      @currentExp = @endExp if @currentExp >= @endExp
    elsif @currentExp > @endExp   # Losing Exp
      @currentExp -= @expIncPerFrame
      @currentExp = @endExp if @currentExp <= @endExp
    end
    # Refresh the Exp bar
    refreshExp
    return if @currentExp != @endExp   # Exp bar still has more to animate
    # Exp bar is completely filled, level up with a flash and sound effect
    if @currentExp >= @rangeExp
      if @expFlash == 0
        pbSEStop
        @expFlash = Graphics.frame_rate / 5
        pbSEPlay("Pkmn exp full")
        self.flash(Color.new(64, 200, 248, 192), @expFlash)
        @sprites.each do |i|
          i[1].flash(Color.new(64, 200, 248, 192), @expFlash) if !i[1].disposed?
        end
      else
        @expFlash -= 1
        @animatingExp = false if @expFlash == 0
      end
    else
      pbSEStop
      # Exp bar has finished filling, end animation
      @animatingExp = false
    end
  end

  QUARTER_ANIM_PERIOD = Graphics.frame_rate * 3 / 20

  def updatePositions(frameCounter)
    self.x = @spriteX
    self.y = @spriteY
    # Data box bobbing while Pokémon is selected
    if @selected == 1 || @selected == 2   # Choosing commands/targeted or damaged
      case (frameCounter / QUARTER_ANIM_PERIOD).floor
      when 1 then self.y = @spriteY - 2
      when 3 then self.y = @spriteY + 2
      end
    end
  end

  def update(frameCounter = 0)
    super()
    # Animate HP bar
    updateHPAnimation
    # Animate Exp bar
    updateExpAnimation
    # Update coordinates of the data box
    updatePositions(frameCounter)
    pbUpdateSpriteHash(@sprites)
  end
end

class Battle::Scene #update shield stuff
  alias bossbattle_pbInitSprites pbInitSprites
  def pbInitSprites
    bossbattle_pbInitSprites
    @battle.battlers.each_with_index do |b, i|
      next if !b
      if b.isbossmon
        @sprites["dataBox_#{i}"] = BossPokemonDataBox.new(b, @battle.pbSideSize(i), @viewport)
      else
        @sprites["dataBox_#{i}"] = PokemonDataBox.new(b, @battle.pbSideSize(i), @viewport)
      end
    end
  end

  def pbRefresh
    @battle.battlers.each_with_index do |b, i|
      next if !b
      sprite = @sprites["dataBox_#{i}"]
      new_databox = false
      if b.isbossmon
        if sprite.is_a?(PokemonDataBox)
          @sprites["dataBox_#{i}"] = BossPokemonDataBox.new(b, @battle.pbSideSize(i), @viewport)
          new_databox = true
        end
      else
        if sprite.is_a?(BossPokemonDataBox)
          @sprites["dataBox_#{i}"] = PokemonDataBox.new(b, @battle.pbSideSize(i), @viewport)
          new_databox = true
        end
      end
      @sprites["dataBox_#{i}"].initializeDataBoxGraphic(@battle.pbSideSize(i)) if new_databox
      @sprites["dataBox_#{i}"]&.refresh
    end
  end

  def pbRefreshOne(idxBattler)
    sprite = @sprites["dataBox_#{idxBattler}"]
    new_databox = false
    if @battle.battlers[idxBattler].isbossmon
      if sprite.is_a?(PokemonDataBox)
        @sprites["dataBox_#{idxBattler}"] = BossPokemonDataBox.new(idxBattler, @battle.pbSideSize(idxBattler), @viewport)
        new_databox = true
      end
    else
      if sprite.is_a?(BossPokemonDataBox)
        @sprites["dataBox_#{idxBattler}"] = PokemonDataBox.new(idxBattler, @battle.pbSideSize(idxBattler), @viewport)
        new_databox = true
      end
    end
    @sprites["dataBox_#{idxBattler}"].initializeDataBoxGraphic(@battle.pbSideSize(idxBattler)) if new_databox
    @sprites["dataBox_#{idxBattler}"]&.refresh
  end

  def pbUpdateShield(shield, index)
    return false if !@battle.battlers[index]
    @battle.battlers[index].pokemon.shieldCount = shield
    @sprites["dataBox_#{index}"].updateshieldDisplay(shield)
  end
end
