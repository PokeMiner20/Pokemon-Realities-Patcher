class CreditBook_Scene
  BASE_LIGHT     = Color.new(220,220,220)
  SHADOW_LIGHT   = Color.new( 25, 25, 25)

  def initialize
    @sprites           = {}
    @viewport          = Viewport.new(0,0,Graphics.width,Graphics.height)
    @viewport.z        = 99999
    @page, @max_pages  = 0, 5
    backgroundFileName = "PDM's Toybox/Credit Book/bg"
    addBackgroundPlanePlugin(@sprites, "bg", backgroundFileName, @viewport)
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    @overlay = @sprites["overlay"].bitmap

    @sprites["leftarrow"] = AnimatedSprite.new("Graphics/Pictures/leftarrow", 8, 40, 28, 2, @viewport)
    @sprites["leftarrow"].x       = 20
    @sprites["leftarrow"].y       = (Graphics.height/2)
    @sprites["leftarrow"].visible = (@page!=0)
    @sprites["leftarrow"].play
    @sprites["rightarrow"] = AnimatedSprite.new("Graphics/Pictures/rightarrow", 8, 40, 28, 2, @viewport)
    @sprites["rightarrow"].x       = Graphics.width - 60
    @sprites["rightarrow"].y       = (Graphics.height/2)
    @sprites["rightarrow"].visible = (@page != (@max_pages-1))
    @sprites["rightarrow"].play

    addDevCredits
    pbFadeInAndShow(@sprites) { pbUpdate }
    loop do
      Graphics.update
      Input.update
      pbUpdate
      if Input.trigger?(Input::BACK) ||  Input.trigger?(Input::USE)
        pbEndScene
        pbPlayCloseMenuSE
        return
      elsif Input.trigger?(Input::LEFT) && @page != 0
        pbPlayCursorSE
        @page -= 1
      elsif Input.trigger?(Input::RIGHT) && @page != (@max_pages-1)
        pbPlayCursorSE
        @page += 1
      end
    end
  end
  
  def addDevCredits
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    currpge = ([0,1,2,3])
    pbSetSystemFont(overlay)
    file_path = "Graphics/Plugins/PDM's Toybox/Credit Book/"
    dev_icon_root = "#{file_path}/dev_icon_"
    dev_data = [
      [["Zero","Lead Dev",""],["Stel76","Spriter",""],["Vermint","Spriter &","Storywriter"],["Skarot","Composer",""]],
      [["PDM20","Coder &","Eventer"],["KliveTheSpectator","Storywriter",""],["Mel","Artist",""],["Nex-Scizor","Artist",""]],
      [["Syntax.Error","Spriter &","Eventer"],["Adjacent","Spriter",""],["Kingsten","Artist",""],["Will0w","Artist",""]],
      [["Shishiboo","Playtester",""],["Robi-Chan","Composer",""],["Tyler","Eventer &","Coder"],["Supernova_ex","Playtester",""]],[["","",""],["","",""],["","",""],["","",""],],]
    dev_icon = [
      ((File.exist?("#{dev_icon_root}#{dev_data[@page][0][0]}.png")) ? "#{dev_icon_root}#{dev_data[@page][0][0]}" : "#{dev_icon_root}unknown"),
      ((File.exist?("#{dev_icon_root}#{dev_data[@page][1][0]}.png")) ? "#{dev_icon_root}#{dev_data[@page][1][0]}" : "#{dev_icon_root}unknown"),
      ((File.exist?("#{dev_icon_root}#{dev_data[@page][2][0]}.png")) ? "#{dev_icon_root}#{dev_data[@page][2][0]}" : "#{dev_icon_root}unknown"),
      ((File.exist?("#{dev_icon_root}#{dev_data[@page][3][0]}.png")) ? "#{dev_icon_root}#{dev_data[@page][3][0]}" : "#{dev_icon_root}unknown"),
    ]
    imagePos = [
      ["#{dev_icon[0]}", 42, 76],
      ["#{dev_icon[1]}",278, 76],
      ["#{dev_icon[2]}", 42,236],
      ["#{dev_icon[3]}",278,236],
    ]
    textPos = [
      [_INTL("#{dev_data[@page][0][0]}"),143, 56, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][0][1]}"),183, 96, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][0][2]}"),183,122, 2, BASE_LIGHT, SHADOW_LIGHT],
      
      [_INTL("#{dev_data[@page][1][0]}"),375, 56, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][1][1]}"),419, 96, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][1][2]}"),419,122, 2, BASE_LIGHT, SHADOW_LIGHT],
      
      [_INTL("#{dev_data[@page][2][0]}"),143,216, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][2][1]}"),183,268, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][2][2]}"),183,294, 2, BASE_LIGHT, SHADOW_LIGHT],
      
      [_INTL("#{dev_data[@page][3][0]}"),375,216, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][3][1]}"),419,268, 2, BASE_LIGHT, SHADOW_LIGHT],
      [_INTL("#{dev_data[@page][3][2]}"),419,294, 2, BASE_LIGHT, SHADOW_LIGHT],

      [_INTL("Page #{@page+1}/#{@max_pages}"), (Graphics.width/2),16, 2, BASE_LIGHT, SHADOW_LIGHT]
    ]
    pbDrawImagePositions(overlay, imagePos)
    pbDrawTextPositions(overlay, textPos)
  end   
    
  def pbEndScene
    pbFadeOutAndHide(@sprites) { pbUpdate }
    pbDisposeSpriteHash(@sprites)
    # DISPOSE OF BITMAPS HERE #
  end

  def pbUpdate
    @sprites["leftarrow"].visible = (@page!=0)
    @sprites["rightarrow"].visible = (@page != (@max_pages-1))
    addDevCredits
    pbUpdateSpriteHash(@sprites)
  end
end

#===============================================================================
#
#===============================================================================
ItemHandlers::UseFromBag.add(:CREDITBOOK, proc { |item|
  pbFadeOutIn { CreditBook_Scene.new }
  next 0
})

def addBackgroundPlanePlugin(sprites, planename, background, viewport = nil)
  sprites[planename] = AnimatedPlane.new(viewport)
  bitmapName = pbResolveBitmap("Graphics/Plugins/#{background}")
  if bitmapName.nil?
    # Plane should exist in any case
    sprites[planename].bitmap = nil
    sprites[planename].visible = false
  else
    sprites[planename].setBitmap(bitmapName)
    sprites.each_value do |spr|
      if spr.is_a?(Window)
        spr.windowskin = nil
      end
    end
  end
end

